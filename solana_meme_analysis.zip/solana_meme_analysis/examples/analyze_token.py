"""
Example script demonstrating how to use the PriceDataCollector with Birdeye API.
"""
import asyncio
from datetime import datetime, timedelta
import pandas as pd
from src.collectors.market.price_collector import PriceDataCollector

async def analyze_token(token_address: str):
    """
    Analyze a token using the PriceDataCollector with Birdeye API.
    
    Args:
        token_address: The Solana token address to analyze
    """
    # Configuration for the price collector
    config = {
        'max_requests_per_minute': 60,
        'interval': '1h'  # 1 hour intervals for historical data
    }
    
    # Calculate time range (last 30 days)
    end_time = datetime.utcnow()
    start_time = end_time - timedelta(days=30)
    
    async with PriceDataCollector(config) as collector:
        # Collect historical price data
        print(f"\nCollecting price data for token: {token_address}")
        price_df = await collector.collect_historical_prices(
            token_address,
            start_time,
            end_time
        )
        
        if not price_df.empty:
            print("\nPrice Statistics:")
            print(f"Current Price: ${price_df['close'].iloc[-1]:.4f}")
            print(f"30-day High: ${price_df['high'].max():.4f}")
            print(f"30-day Low: ${price_df['low'].min():.4f}")
        
        # Collect volume data
        volume_df = await collector.collect_trading_volume(
            token_address,
            start_time,
            end_time
        )
        
        if not volume_df.empty:
            print("\nVolume Statistics:")
            print(f"Total Volume (30d): ${volume_df['volume_usd'].sum():.2f}")
            print(f"Average Daily Volume: ${volume_df['volume_usd'].mean():.2f}")
            print(f"Total Trades: {volume_df['trade_count'].sum()}")
        
        # Collect current liquidity data
        liquidity_data = await collector.collect_liquidity_data(token_address)
        
        if liquidity_data:
            print("\nLiquidity Information:")
            print(f"Total Liquidity: ${liquidity_data['total_liquidity_usd']:.2f}")
            print(f"Token Liquidity: {liquidity_data['token_liquidity']:.2f}")
            print(f"Number of LP Providers: {liquidity_data['liquidity_providers']}")

async def main():
    """Main function to run the example."""
    # Example token address (BONK)
    token_address = "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"
    
    try:
        await analyze_token(token_address)
    except Exception as e:
        print(f"Error analyzing token: {str(e)}")

if __name__ == "__main__":
    asyncio.run(main())
