"""
Example script demonstrating quick pattern analysis for meme coins using short timeframes.
"""
import asyncio
from datetime import datetime, timedelta
import json
from pathlib import Path
import pandas as pd
from src.analysis.price.historical_analysis import HistoricalAnalysis
from src.collectors.market.price_collector import PriceDataCollector
from src.collectors.social.social_collector import SocialDataCollector

async def analyze_quick_patterns(token_address: str = None):
    """
    Analyze patterns in short timeframes (1m, 1h) for rapid market movements.
    
    Args:
        token_address: Optional specific token to analyze. If None, analyzes top tokens.
    """
    # Load configuration
    config_path = Path('config/analysis_config.json')
    with open(config_path) as f:
        config = json.load(f)
    
    # Initialize collectors
    collector = PriceDataCollector(config)
    
    print("\nInitializing quick pattern analysis...")
    
    async with collector:
        if token_address:
            # Analyze specific token
            tokens = [await collector._get_token_performance(token_address)]
        else:
            # Get top 20 tokens by volume
            print("\nFetching top performing tokens...")
            tokens = await collector.get_top_performing_tokens(
                limit=20,
                min_liquidity=config['data_collection']['min_liquidity_usd']
            )
        
        if not tokens:
            print("No tokens found for analysis.")
            return
        
        print(f"\nAnalyzing {len(tokens)} tokens for quick patterns...")
        
        # Initialize analysis
        data_dir = Path('data')
        analyzer = HistoricalAnalysis(data_dir, config)
        
        # Analyze each token
        for token in tokens:
            symbol = token['symbol']
            print(f"\nAnalyzing {symbol}...")
            
            # Prepare OHLCV data from both timeframes
            minute_data = pd.DataFrame({
                'timestamp': pd.to_datetime(token.get('1m_timestamp', [])),
                'open': token.get('1m_open', []),
                'high': token.get('1m_high', []),
                'low': token.get('1m_low', []),
                'close': token.get('1m_close', []),
                'volume': token.get('1m_volume', [])
            }).set_index('timestamp')
            
            hour_data = pd.DataFrame({
                'timestamp': pd.to_datetime(token.get('1h_timestamp', [])),
                'open': token.get('1h_open', []),
                'high': token.get('1h_high', []),
                'low': token.get('1h_low', []),
                'close': token.get('1h_close', []),
                'volume': token.get('1h_volume', [])
            }).set_index('timestamp')
            
            # Analyze patterns in both timeframes
            minute_patterns = analyzer.pattern_recognition.analyze_breakout_patterns(
                minute_data
            ) if not minute_data.empty else []
            
            hour_patterns = analyzer.pattern_recognition.analyze_breakout_patterns(
                hour_data
            ) if not hour_data.empty else []
            
            # Print findings
            print(f"\n{symbol} Analysis Results:")
            print("------------------------")
            
            # 1-minute timeframe analysis
            if minute_patterns:
                print("\n1-Minute Timeframe Patterns:")
                for pattern in minute_patterns:
                    confidence = pattern['confidence_score']
                    if confidence >= 0.8:  # High confidence patterns only
                        print(f"- {pattern['breakout_type'].title()} breakout detected at "
                              f"{pattern['timestamp'].strftime('%Y-%m-%d %H:%M')}")
                        print(f"  Confidence: {confidence:.2f}")
                        print(f"  Price: ${pattern['price']:.6f}")
                        print(f"  Volume Spike: {pattern.get('volume_increase', 0):.1f}x")
                        
                        # Print confidence factors
                        factors = pattern['confidence_factors']
                        print("  Confidence Breakdown:")
                        print(f"    Price: {factors['price']:.2f}")
                        print(f"    Volume: {factors['volume']:.2f}")
                        print(f"    Technical: {factors['technical']:.2f}")
            else:
                print("\nNo significant 1-minute patterns detected")
            
            # 1-hour timeframe analysis
            if hour_patterns:
                print("\n1-Hour Timeframe Patterns:")
                for pattern in hour_patterns:
                    confidence = pattern['confidence_score']
                    if confidence >= 0.8:  # High confidence patterns only
                        print(f"- {pattern['breakout_type'].title()} breakout detected at "
                              f"{pattern['timestamp'].strftime('%Y-%m-%d %H:%M')}")
                        print(f"  Confidence: {confidence:.2f}")
                        print(f"  Price: ${pattern['price']:.6f}")
                        print(f"  Volume Spike: {pattern.get('volume_increase', 0):.1f}x")
                        
                        # Print confidence factors
                        factors = pattern['confidence_factors']
                        print("  Confidence Breakdown:")
                        print(f"    Price: {factors['price']:.2f}")
                        print(f"    Volume: {factors['volume']:.2f}")
                        print(f"    Technical: {factors['technical']:.2f}")
            else:
                print("\nNo significant 1-hour patterns detected")
            
            # Print current market metrics
            print("\nCurrent Market Metrics:")
            print(f"Price: ${token['price']:.6f}")
            print(f"24h Volume: ${token['volume_24h']:,.2f}")
            print(f"Liquidity: ${token['liquidity']:,.2f}")
            print(f"Buy/Sell Ratio: {token['buy_volume_24h']/token['sell_volume_24h']:.2f}")
            
            # Print volatility metrics
            print("\nVolatility Metrics:")
            print(f"1m Volatility: {token.get('1m_volatility', 0):.2f}%")
            print(f"1h Volatility: {token.get('1h_volatility', 0):.2f}%")
            print(f"1m Max Drawdown: {token.get('1m_max_drawdown', 0):.2f}%")
            print(f"1h Max Drawdown: {token.get('1h_max_drawdown', 0):.2f}%")
            
            # Save detailed analysis to file
            analysis_file = data_dir / f'quick_analysis_{symbol}_{datetime.now().strftime("%Y%m%d_%H%M")}.json'
            analysis_data = {
                'token': token,
                'minute_patterns': minute_patterns,
                'hour_patterns': hour_patterns,
                'timestamp': datetime.now().isoformat()
            }
            
            with open(analysis_file, 'w') as f:
                json.dump(analysis_data, f, indent=2, default=str)
            
            print(f"\nDetailed analysis saved to {analysis_file}")

async def main():
    """Main function to run the analysis."""
    try:
        # You can pass a specific token address or None to analyze top tokens
        await analyze_quick_patterns()
    except Exception as e:
        print(f"Error during analysis: {str(e)}")

if __name__ == "__main__":
    asyncio.run(main())
