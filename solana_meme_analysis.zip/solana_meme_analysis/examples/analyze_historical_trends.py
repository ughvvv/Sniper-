"""
Example script demonstrating comprehensive historical trend analysis for meme coins.
"""
import asyncio
from datetime import datetime, timedelta
import json
from pathlib import Path
import pandas as pd
from src.analysis.price.historical_analysis import HistoricalAnalysis
from src.collectors.market.price_collector import PriceDataCollector
from src.collectors.social.social_collector import SocialDataCollector

async def analyze_historical_trends():
    """Analyze historical trends in meme coin performance and social metrics."""
    # Initialize analysis with data directory
    data_dir = Path('data')
    analyzer = HistoricalAnalysis(data_dir)
    
    # Load historical data from the past 30 days
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=30)
    
    print(f"\nLoading historical data from {start_date.date()} to {end_date.date()}...")
    historical_data = analyzer.load_historical_data(start_date, end_date)
    
    if historical_data.empty:
        print("No historical data found. Please run analyze_top_memecoins.py first.")
        return
    
    print(f"\nAnalyzing {len(historical_data['address'].unique())} unique tokens...")
    
    # Analyze performance trends
    print("\nAnalyzing market trends...")
    market_stats = analyzer.analyze_performance_trends(historical_data)
    
    if market_stats:
        # Save detailed market statistics
        stats_file = data_dir / f'market_stats_{end_date.strftime("%Y%m%d")}.json'
        with open(stats_file, 'w') as f:
            json.dump(market_stats, f, indent=2)
        
        print("\n=== Market Overview ===")
        print(f"Total Tokens Analyzed: {market_stats['total_tokens_analyzed']}")
        print(f"Tokens with Positive Trend: {market_stats['positive_trend_count']}")
        print(f"Tokens with Negative Trend: {market_stats['negative_trend_count']}")
        print(f"Average Social Presence Score: {market_stats['avg_social_presence']:.2f}")
        print(f"Average Wallet Retention Rate: {market_stats['avg_wallet_retention']:.2f}%")
        print(f"Average Buy/Sell Ratio: {market_stats['avg_buy_sell_ratio']:.2f}")
        
        print("\n=== Top 10 Performers ===")
        for token in market_stats['top_performers']:
            print(f"\n{token['symbol']} ({token['name']})")
            print(f"Price Trend: {token['price_trend']:.2f}")
            print(f"Volume Trend: {token['volume_trend']:.2f}")
            print(f"Market Maturity Score: {token['market_maturity_score']:.2f}")
            print(f"Trading Activity Score: {token['trading_activity_score']:.2f}")
            print(f"Social Score: {token['social_presence_score']:.2f}")
            
            # Display wallet activity
            print(f"Daily Active Wallets: {token['avg_daily_active_wallets']:,.0f}")
            print(f"Wallet Growth Rate: {token['wallet_growth_rate']:.1f}%")
            print(f"Wallet Retention: {token['wallet_retention_rate']:.1f}%")
            
            # Display trading patterns
            print(f"Buy/Sell Ratio: {token['buy_sell_ratio']:.2f}")
            print(f"Avg Trade Size: ${token['avg_trade_size']:,.2f}")
        
        print("\n=== Top Social Growth ===")
        for token in market_stats['top_social_growth']:
            print(f"\n{token['symbol']}")
            print(f"Social Growth Score: {token['social_growth_score']:.2f}")
            print(f"Social Score Growth: {token['social_score_growth']:.1f}%")
            
            # Display platform-specific growth
            for platform, growth in token['platform_growth'].items():
                if growth != 0:
                    print(f"{platform.capitalize()} Growth: {growth:+.1f}%")
        
        print("\n=== Most Active Trading ===")
        for token in market_stats['most_active_trading']:
            print(f"\n{token['symbol']}")
            print(f"Trading Activity Score: {token['trading_activity_score']:.2f}")
            print(f"Daily Trades: {token['trade_frequency']:.1f}")
            print(f"Buy/Sell Ratio: {token['buy_sell_ratio']:.2f}")
            print(f"Market Depth: ${token['avg_liquidity_per_market']:,.2f}")
        
        # Generate market insights
        print("\n=== Market Insights ===")
        
        # Analyze correlation between metrics
        correlations = _analyze_metric_correlations(historical_data)
        print("\nKey Correlations:")
        for correlation in correlations:
            print(f"- {correlation}")
        
        # Identify emerging patterns
        patterns = _identify_emerging_patterns(market_stats)
        print("\nEmerging Patterns:")
        for pattern in patterns:
            print(f"- {pattern}")
        
        # Generate trading volume analysis
        volume_insights = _analyze_trading_volumes(historical_data)
        print("\nTrading Volume Insights:")
        for insight in volume_insights:
            print(f"- {insight}")

def _analyze_metric_correlations(data: pd.DataFrame) -> List[str]:
    """Analyze correlations between different metrics."""
    insights = []
    
    # Calculate correlation between price change and wallet activity
    price_wallet_corr = data['price_change_percent'].corr(
        data['unique_wallets_24h']
    )
    insights.append(
        f"Price change and wallet activity correlation: {price_wallet_corr:.2f}"
    )
    
    # Calculate correlation between volume and social presence
    volume_social_corr = data['volume_24h'].corr(
        data['social_presence_score']
    )
    insights.append(
        f"Volume and social presence correlation: {volume_social_corr:.2f}"
    )
    
    # Calculate correlation between liquidity and holder count
    liquidity_holder_corr = data['liquidity'].corr(
        data['holder_count']
    )
    insights.append(
        f"Liquidity and holder count correlation: {liquidity_holder_corr:.2f}"
    )
    
    return insights

def _identify_emerging_patterns(market_stats: Dict) -> List[str]:
    """Identify emerging patterns in the market."""
    patterns = []
    
    # Analyze trend distribution
    trend_ratio = (
        market_stats['positive_trend_count'] /
        (market_stats['positive_trend_count'] + market_stats['negative_trend_count'])
    )
    if trend_ratio > 0.6:
        patterns.append("Strong bullish market sentiment (>60% positive trends)")
    elif trend_ratio < 0.4:
        patterns.append("Strong bearish market sentiment (<40% positive trends)")
    
    # Analyze social growth patterns
    avg_social_growth = np.mean([
        token['social_growth_score']
        for token in market_stats['top_performers']
    ])
    if avg_social_growth > 50:
        patterns.append("High social media growth among top performers")
    
    # Analyze trading patterns
    avg_buy_sell = market_stats['avg_buy_sell_ratio']
    if avg_buy_sell > 1.5:
        patterns.append("Strong buying pressure (buy/sell ratio >1.5)")
    elif avg_buy_sell < 0.7:
        patterns.append("Strong selling pressure (buy/sell ratio <0.7)")
    
    return patterns

def _analyze_trading_volumes(data: pd.DataFrame) -> List[str]:
    """Analyze trading volume patterns."""
    insights = []
    
    # Calculate average daily volume change
    volume_change = data.groupby('snapshot_date')['volume_24h'].mean().pct_change()
    avg_volume_change = volume_change.mean() * 100
    
    if abs(avg_volume_change) > 20:
        direction = "increasing" if avg_volume_change > 0 else "decreasing"
        insights.append(
            f"Market volume significantly {direction} "
            f"({abs(avg_volume_change):.1f}% average daily change)"
        )
    
    # Analyze volume concentration
    top_volume_share = (
        data.nlargest(10, 'volume_24h')['volume_24h'].sum() /
        data['volume_24h'].sum() * 100
    )
    insights.append(
        f"Top 10 tokens account for {top_volume_share:.1f}% of total volume"
    )
    
    return insights

async def main():
    """Main function to run the analysis."""
    try:
        await analyze_historical_trends()
    except Exception as e:
        print(f"Error during analysis: {str(e)}")

if __name__ == "__main__":
    asyncio.run(main())
