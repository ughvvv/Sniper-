"""
Example script demonstrating order book analysis functionality.
"""
import asyncio
import logging
from datetime import datetime, timedelta
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
from src.collectors.market.order_book_collector import OrderBookCollector
from src.analysis.price.historical_analysis import HistoricalAnalysis
from src.config.settings import DATA_DIR, PATTERN_RECOGNITION

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def analyze_token_order_book(
    token_address: str,
    days_back: int = 7
) -> None:
    """
    Analyze order book data for a specific token.
    
    Args:
        token_address: The token's contract address
        days_back: Number of days of historical data to analyze
    """
    try:
        # Initialize collectors and analyzers
        config = {'pattern_recognition': PATTERN_RECOGNITION}
        order_book_collector = OrderBookCollector(config)
        historical_analyzer = HistoricalAnalysis(DATA_DIR, config)
        
        # Calculate time range
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(days=days_back)
        
        logger.info(f"Collecting order book data for token {token_address}")
        logger.info(f"Time range: {start_time} to {end_time}")
        
        # Collect order book data
        async with order_book_collector:
            order_book_data = await order_book_collector.collect_order_book_data(
                token_address,
                start_time,
                end_time,
                depth=10,
                interval='1h'
            )
        
        if order_book_data.empty:
            logger.error("No order book data collected")
            return
        
        # Calculate and display key metrics
        logger.info("\nOrder Book Analysis Results:")
        
        # Group data by timestamp for time-series analysis
        timestamps = order_book_data['timestamp'].unique()
        
        spreads = []
        depths = []
        imbalances = []
        
        for timestamp in timestamps:
            time_data = order_book_data[order_book_data['timestamp'] == timestamp]
            
            # Get best bid and ask
            best_bid = time_data[
                (time_data['side'] == 'bid') & (time_data['level'] == 1)
            ]['price'].iloc[0]
            best_ask = time_data[
                (time_data['side'] == 'ask') & (time_data['level'] == 1)
            ]['price'].iloc[0]
            
            # Calculate metrics
            spread = (best_ask - best_bid) / best_bid * 100
            total_depth = time_data['size'].sum()
            
            bid_volume = time_data[time_data['side'] == 'bid']['size'].sum()
            ask_volume = time_data[time_data['side'] == 'ask']['size'].sum()
            imbalance = (bid_volume - ask_volume) / (bid_volume + ask_volume)
            
            spreads.append(spread)
            depths.append(total_depth)
            imbalances.append(imbalance)
        
        # Create time series data
        ts_data = pd.DataFrame({
            'timestamp': timestamps,
            'spread': spreads,
            'depth': depths,
            'imbalance': imbalances
        })
        
        # Display summary statistics
        logger.info("\nSummary Statistics:")
        logger.info(f"Average Spread: {ts_data['spread'].mean():.2f}%")
        logger.info(f"Average Depth: {ts_data['depth'].mean():.2f}")
        logger.info(f"Average Imbalance: {ts_data['imbalance'].mean():.2f}")
        logger.info(f"Spread Volatility: {ts_data['spread'].std():.2f}%")
        logger.info(f"Depth Stability: {1 - ts_data['depth'].std() / ts_data['depth'].mean():.2f}")
        
        # Visualize the metrics
        fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(12, 10))
        
        # Plot spread
        ax1.plot(ts_data['timestamp'], ts_data['spread'], label='Bid-Ask Spread %')
        ax1.set_title('Bid-Ask Spread Over Time')
        ax1.set_ylabel('Spread %')
        ax1.grid(True)
        
        # Plot depth
        ax2.plot(ts_data['timestamp'], ts_data['depth'], label='Order Book Depth')
        ax2.set_title('Market Depth Over Time')
        ax2.set_ylabel('Total Size')
        ax2.grid(True)
        
        # Plot imbalance
        ax3.plot(ts_data['timestamp'], ts_data['imbalance'], label='Bid/Ask Imbalance')
        ax3.set_title('Order Book Imbalance Over Time')
        ax3.set_ylabel('Imbalance (-1 to 1)')
        ax3.grid(True)
        
        plt.tight_layout()
        
        # Save the plot
        output_dir = Path('visualizations')
        output_dir.mkdir(exist_ok=True)
        plt.savefig(output_dir / f'order_book_analysis_{datetime.now():%Y%m%d_%H%M%S}.png')
        logger.info(f"\nVisualization saved to {output_dir}")
        
        # Identify potential trading opportunities
        logger.info("\nTrading Signals:")
        
        # Look for tight spreads with high depth
        good_liquidity = ts_data[
            (ts_data['spread'] < ts_data['spread'].mean()) &
            (ts_data['depth'] > ts_data['depth'].mean())
        ]
        
        if not good_liquidity.empty:
            logger.info(f"Found {len(good_liquidity)} periods of good liquidity conditions")
            
        # Look for significant imbalances
        significant_imbalance = ts_data[abs(ts_data['imbalance']) > 0.2]
        if not significant_imbalance.empty:
            logger.info(
                f"Found {len(significant_imbalance)} periods with significant order book imbalance"
            )
        
    except Exception as e:
        logger.error(f"Error analyzing order book: {str(e)}")

async def main():
    """Main execution function."""
    # Example token address (replace with actual token address)
    token_address = "YOUR_TOKEN_ADDRESS_HERE"
    
    await analyze_token_order_book(token_address)

if __name__ == "__main__":
    asyncio.run(main())
