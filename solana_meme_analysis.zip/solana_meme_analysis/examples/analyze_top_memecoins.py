"""
Example script demonstrating how to analyze top performing meme coins with social data.
"""
import asyncio
import json
from datetime import datetime, timedelta
import pandas as pd
from pathlib import Path
from src.collectors.market.price_collector import PriceDataCollector
from src.collectors.social.social_collector import SocialDataCollector

async def analyze_top_memecoins(days: int = 30):
    """
    Analyze top performing meme coins and their social presence.
    
    Args:
        days: Number of days to analyze
    """
    # Configuration
    config = {
        'max_requests_per_minute': 60,
        'twitter_requests_per_15min': 450,
        'min_liquidity': 10000  # $10k minimum liquidity
    }
    
    # Create data directory if it doesn't exist
    data_dir = Path('data')
    data_dir.mkdir(exist_ok=True)
    
    print(f"\nFetching top performing tokens over the last {days} days...")
    
    async with PriceDataCollector(config) as price_collector, \
               SocialDataCollector(config) as social_collector:
        
        # Get top performing tokens
        top_tokens = await price_collector.get_top_performing_tokens(
            limit=1000,
            days=days,
            min_liquidity=config['min_liquidity']
        )
        
        if not top_tokens:
            print("No tokens found matching criteria")
            return
        
        print(f"\nFound {len(top_tokens)} tokens. Collecting social data...")
        
        # Collect social data for each token
        token_addresses = [token['address'] for token in top_tokens]
        social_data = await social_collector.batch_collect_social_data(token_addresses)
        
        # Combine price and social data
        combined_data = []
        for token, social in zip(top_tokens, social_data):
            if 'error' not in social:
                # Get Twitter engagement if available
                twitter_metrics = {}
                if social.get('twitter_handle'):
                    print(f"\nAnalyzing Twitter engagement for {token['symbol']}...")
                    twitter_metrics = await social_collector.analyze_twitter_engagement(
                        social['twitter_handle'],
                        datetime.utcnow() - timedelta(days=days)
                    )
                
                combined_data.append({
                    # Token info
                    'address': token['address'],
                    'symbol': token['symbol'],
                    'name': token['name'],
                    
                    # Price metrics
                    'current_price': token['price'],
                    'price_change_percent': token['price_change_percent'],
                    'volume_24h': token['volume_24h'],
                    'liquidity': token['liquidity'],
                    'high': token['high'],
                    'low': token['low'],
                    'avg_volume': token['avg_volume'],
                    
                    # Social presence
                    'has_twitter': bool(social.get('twitter_handle')),
                    'has_telegram': bool(social.get('telegram_url')),
                    'has_website': bool(social.get('website')),
                    'has_discord': bool(social.get('discord')),
                    
                    # Social metrics
                    'twitter_handle': social.get('twitter_handle'),
                    'twitter_engagement_rate': twitter_metrics.get('engagement_rate'),
                    'twitter_followers_growth': twitter_metrics.get('followers_growth'),
                    'twitter_avg_likes': twitter_metrics.get('avg_likes'),
                    'twitter_avg_retweets': twitter_metrics.get('avg_retweets'),
                    
                    # Additional social links
                    'telegram_url': social.get('telegram_url'),
                    'website': social.get('website'),
                    'discord': social.get('discord')
                })
        
        # Convert to DataFrame for analysis
        df = pd.DataFrame(combined_data)
        
        # Save raw data
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        df.to_csv(data_dir / f'top_memecoins_{timestamp}.csv', index=False)
        
        # Save detailed JSON data
        with open(data_dir / f'top_memecoins_detailed_{timestamp}.json', 'w') as f:
            json.dump(combined_data, f, indent=2)
        
        # Print summary statistics
        print("\nSummary Statistics:")
        print(f"Total tokens analyzed: {len(df)}")
        print(f"Tokens with Twitter: {df['has_twitter'].sum()}")
        print(f"Tokens with Telegram: {df['has_telegram'].sum()}")
        print(f"Tokens with Website: {df['has_website'].sum()}")
        print(f"Tokens with Discord: {df['has_discord'].sum()}")
        
        print("\nTop 10 Performers:")
        top_10 = df.nlargest(10, 'price_change_percent')
        for _, token in top_10.iterrows():
            print(f"\n{token['symbol']} ({token['name']})")
            print(f"Price Change: {token['price_change_percent']:.2f}%")
            print(f"Current Price: ${token['current_price']:.6f}")
            print(f"24h Volume: ${token['volume_24h']:,.2f}")
            print(f"Liquidity: ${token['liquidity']:,.2f}")
            if token['twitter_handle']:
                print(f"Twitter: @{token['twitter_handle']}")
                if token['twitter_engagement_rate']:
                    print(f"Twitter Engagement Rate: {token['twitter_engagement_rate']:.2f}%")

async def main():
    """Main function to run the analysis."""
    try:
        await analyze_top_memecoins()
    except Exception as e:
        print(f"Error during analysis: {str(e)}")

if __name__ == "__main__":
    asyncio.run(main())
