"""
Example script demonstrating launch period analysis with granular Solana correlation.
"""
import asyncio
from datetime import datetime, timedelta
import json
from pathlib import Path
import pandas as pd
from typing import List, Dict
from src.analysis.price.launch_analyzer import LaunchAnalyzer
from src.collectors.market.price_collector import PriceDataCollector
from src.collectors.social.social_collector import SocialDataCollector

def print_interval_analysis(metrics: Dict, interval: str):
    """Print analysis for a specific time interval."""
    print(f"\n{interval} Analysis:")
    print("-" * 20)
    
    # Price changes
    price_metrics = metrics['price_changes']
    print(f"Price Changes:")
    print(f"  Mean: {price_metrics.get('mean', 0):.2f}%")
    print(f"  Max: {price_metrics.get('max', 0):.2f}%")
    print(f"  Min: {price_metrics.get('min', 0):.2f}%")
    print(f"  Volatility: {price_metrics.get('std', 0):.2f}")
    
    # Volume profile
    volume_metrics = metrics['volume_profile']
    print(f"Volume Profile:")
    print(f"  Mean Volume: {volume_metrics.get('mean', 0):,.0f}")
    print(f"  Volume Trend: {volume_metrics.get('trend', 0):.2f}")
    
    # Trade metrics
    trade_metrics = metrics['trade_metrics']
    print(f"Trade Activity:")
    print(f"  Avg Buy/Sell Ratio: {trade_metrics.get('avg_ratio', 1):.2f}")
    print(f"  Volume Trend: {trade_metrics.get('volume_trend', 0):.2f}")
    
    # SOL correlation
    corr_metrics = metrics['sol_correlation']
    print(f"Solana Correlation:")
    print(f"  Mean Correlation: {corr_metrics.get('mean_correlation', 0):.2f}")
    print(f"  Mean Beta: {corr_metrics.get('mean_beta', 0):.2f}")
    print(f"  Correlation Trend: {corr_metrics.get('correlation_trend', 0):.2f}")
    
    # Wallet activity
    wallet_metrics = metrics['wallet_activity']
    print(f"Wallet Activity:")
    print(f"  Avg Unique Wallets: {wallet_metrics.get('avg_unique_wallets', 0):,.0f}")
    print(f"  Avg Trades/Wallet: {wallet_metrics.get('avg_trades_per_wallet', 0):.2f}")
    print(f"  Wallet Growth: {wallet_metrics.get('wallet_growth', 0):.2f}")

async def analyze_launch_patterns(specific_tokens: List[str] = None):
    """
    Analyze token patterns during their launch period (first 10 days).
    
    Args:
        specific_tokens: Optional list of token addresses to analyze.
                       If None, analyzes recent launches.
    """
    # Load configuration
    config_path = Path('config/analysis_config.json')
    with open(config_path) as f:
        config = json.load(f)
    
    # Initialize collectors
    price_collector = PriceDataCollector(config)
    launch_analyzer = LaunchAnalyzer(price_collector)
    
    print("\nInitializing launch period analysis...")
    
    async with price_collector:
        if specific_tokens:
            tokens_to_analyze = specific_tokens
        else:
            # Get recent launches (tokens less than 30 days old)
            print("\nFetching recent token launches...")
            all_tokens = await price_collector.get_top_performing_tokens(
                limit=100,
                min_liquidity=config['data_collection']['min_liquidity_usd']
            )
            
            thirty_days_ago = datetime.utcnow() - timedelta(days=30)
            tokens_to_analyze = [
                token['address'] for token in all_tokens
                if datetime.fromisoformat(token['last_trade_time']) > thirty_days_ago
            ]
        
        if not tokens_to_analyze:
            print("No tokens found for analysis.")
            return
        
        print(f"\nAnalyzing {len(tokens_to_analyze)} tokens...")
        
        # Store results for comparative analysis
        launch_results = []
        
        # Analyze each token
        for token_address in tokens_to_analyze:
            try:
                # Get token info
                token_info = await price_collector._get_token_performance(token_address)
                if not token_info:
                    continue
                
                print(f"\nAnalyzing {token_info['symbol']}...")
                
                # Analyze launch period
                metrics = await launch_analyzer.analyze_launch_period(token_address)
                
                result = {
                    'address': token_address,
                    'symbol': token_info['symbol'],
                    'name': token_info['name'],
                    'launch_date': metrics.launch_date.isoformat(),
                    'initial_price': metrics.initial_price,
                    'peak_price': metrics.peak_price,
                    'time_to_peak': str(metrics.time_to_peak),
                    'price_increase': metrics.price_increase,
                    'volatility': metrics.volatility,
                    'correlation_with_sol': metrics.correlation_with_sol,
                    'beta_with_sol': metrics.beta_with_sol,
                    'relative_strength': metrics.relative_strength,
                    'launch_momentum': metrics.launch_momentum,
                    'price_discovery_hours': metrics.price_discovery_phase,
                    'success_score': metrics.success_score,
                    'granular_metrics': metrics.granular_metrics
                }
                
                launch_results.append(result)
                
                # Print comprehensive analysis
                print(f"\n{token_info['symbol']} Launch Analysis:")
                print("=" * 50)
                print(f"Launch Date: {metrics.launch_date.strftime('%Y-%m-%d %H:%M:%S')}")
                print(f"Initial Price: ${metrics.initial_price:.6f}")
                print(f"Peak Price: ${metrics.peak_price:.6f}")
                print(f"Time to Peak: {metrics.time_to_peak}")
                print(f"Price Increase: {metrics.price_increase:.1f}%")
                print(f"Overall Volatility: {metrics.volatility:.2f}")
                
                print("\nSolana Relationship:")
                print(f"Overall Correlation: {metrics.correlation_with_sol:.2f}")
                print(f"Overall Beta: {metrics.beta_with_sol:.2f}")
                print(f"Relative Strength: {metrics.relative_strength:.2f}")
                
                print("\nLaunch Characteristics:")
                print(f"Launch Momentum: {metrics.launch_momentum:.2f}")
                print(f"Price Discovery Phase: {metrics.price_discovery_phase} hours")
                print(f"Success Score: {metrics.success_score:.2f}")
                
                # Print granular analysis for each time interval
                for interval in ['30m', '1h', '2h', '4h', '8h', '24h']:
                    if interval in metrics.granular_metrics:
                        print_interval_analysis(
                            metrics.granular_metrics[interval],
                            interval
                        )
                
            except Exception as e:
                print(f"Error analyzing {token_address}: {str(e)}")
                continue
        
        if launch_results:
            # Save detailed results
            output_dir = Path('data/launch_analysis')
            output_dir.mkdir(parents=True, exist_ok=True)
            
            output_file = output_dir / f'launch_analysis_{datetime.now().strftime("%Y%m%d_%H%M")}.json'
            with open(output_file, 'w') as f:
                json.dump(launch_results, f, indent=2)
            
            # Calculate and print aggregate statistics
            df = pd.DataFrame(launch_results)
            
            print("\n=== Aggregate Launch Statistics ===")
            print(f"\nTotal Tokens Analyzed: {len(df)}")
            print(f"Average Launch Success Score: {df['success_score'].mean():.2f}")
            print(f"Average SOL Correlation: {df['correlation_with_sol'].mean():.2f}")
            print(f"Average Price Increase: {df['price_increase'].mean():.1f}%")
            print(f"Average Time to Peak: {pd.to_timedelta(df['time_to_peak']).mean()}")
            print(f"Average Price Discovery Hours: {df['price_discovery_hours'].mean():.1f}")
            
            # Identify patterns
            print("\n=== Launch Patterns ===")
            
            # SOL correlation patterns
            high_sol_corr = df[df['correlation_with_sol'] > 0.7]
            if not high_sol_corr.empty:
                print(f"\nTokens with High SOL Correlation ({len(high_sol_corr)}):")
                for _, token in high_sol_corr.iterrows():
                    print(f"- {token['symbol']}: {token['correlation_with_sol']:.2f}")
            
            # Success patterns
            successful_launches = df[df['success_score'] > 0.8]
            if not successful_launches.empty:
                print(f"\nMost Successful Launches ({len(successful_launches)}):")
                for _, token in successful_launches.iterrows():
                    print(f"- {token['symbol']}: {token['success_score']:.2f}")
            
            # Quick price discovery
            quick_discovery = df[df['price_discovery_hours'] < 24]
            if not quick_discovery.empty:
                print(f"\nQuick Price Discovery Tokens ({len(quick_discovery)}):")
                for _, token in quick_discovery.iterrows():
                    print(f"- {token['symbol']}: {token['price_discovery_hours']:.1f} hours")
            
            print(f"\nDetailed results saved to {output_file}")

async def main():
    """Main function to run the analysis."""
    try:
        # You can pass specific token addresses or None to analyze recent launches
        await analyze_launch_patterns()
    except Exception as e:
        print(f"Error during analysis: {str(e)}")

if __name__ == "__main__":
    asyncio.run(main())
