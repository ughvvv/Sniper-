"""
Example script demonstrating the usage of the improved pattern recognition system.
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
from pathlib import Path
import sys

# Add project root to Python path
project_root = Path(__file__).resolve().parent.parent
sys.path.append(str(project_root))

from src.analysis.price.pattern_recognition import PatternRecognition
from src.collectors.market.price_collector import PriceCollector
from src.config.settings import PATTERN_RECOGNITION

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
logger = logging.getLogger(__name__)

def load_sample_data(symbol: str, days: int = 30) -> pd.DataFrame:
    """
    Load price data for analysis.
    
    Args:
        symbol: Token symbol
        days: Number of days of historical data
        
    Returns:
        DataFrame with OHLCV data
    """
    try:
        # Initialize price collector
        collector = PriceCollector()
        
        # Get historical data
        df = collector.get_historical_prices(
            symbol,
            start_date=(datetime.now() - timedelta(days=days)),
            end_date=datetime.now()
        )
        
        logger.info(f"Loaded {len(df)} data points for {symbol}")
        return df
        
    except Exception as e:
        logger.error(f"Error loading data: {str(e)}")
        raise

def analyze_token_patterns(
    symbol: str,
    output_dir: str = "output",
    days: int = 30
) -> None:
    """
    Analyze trading patterns for a specific token.
    
    Args:
        symbol: Token symbol
        output_dir: Directory to save visualizations
        days: Number of days of historical data
    """
    try:
        logger.info(f"Starting pattern analysis for {symbol}")
        
        # Create output directory
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Load data
        df = load_sample_data(symbol, days)
        
        # Initialize pattern recognition with default config
        pattern_recognition = PatternRecognition()
        
        # Analyze patterns
        patterns, visualization_paths = pattern_recognition.analyze_breakout_patterns(
            df,
            save_visualizations=True,
            output_dir=str(output_path)
        )
        
        # Log results
        logger.info(f"Found {len(patterns)} potential patterns")
        
        # Print pattern details
        for i, pattern in enumerate(patterns, 1):
            logger.info(f"\nPattern {i}:")
            logger.info(f"Type: {pattern['breakout_type']}")
            logger.info(f"Timestamp: {pattern['timestamp']}")
            logger.info(f"Price: {pattern['price']:.4f}")
            logger.info(f"Confidence: {pattern['confidence_score']:.2f}")
            
            if 'ml_confidence' in pattern:
                logger.info(f"ML Confidence: {pattern['ml_confidence']:.2f}")
                
        # Log visualization paths
        if visualization_paths:
            logger.info("\nGenerated visualizations:")
            for viz_type, path in visualization_paths.items():
                logger.info(f"{viz_type}: {path}")
                
    except Exception as e:
        logger.error(f"Error in pattern analysis: {str(e)}")
        raise

def analyze_multiple_tokens(
    symbols: list,
    output_dir: str = "output",
    days: int = 30
) -> None:
    """
    Analyze patterns for multiple tokens.
    
    Args:
        symbols: List of token symbols
        output_dir: Base directory for outputs
        days: Number of days of historical data
    """
    try:
        logger.info(f"Starting analysis for {len(symbols)} tokens")
        
        for symbol in symbols:
            # Create token-specific output directory
            token_output = Path(output_dir) / symbol
            
            try:
                analyze_token_patterns(
                    symbol,
                    output_dir=str(token_output),
                    days=days
                )
                
            except Exception as e:
                logger.error(f"Error analyzing {symbol}: {str(e)}")
                continue
                
        logger.info("Completed analysis for all tokens")
        
    except Exception as e:
        logger.error(f"Error in batch analysis: {str(e)}")
        raise

def main():
    """Main execution function."""
    try:
        # Example usage
        # Single token analysis
        analyze_token_patterns(
            symbol="BONK/USD",
            output_dir="output/single",
            days=30
        )
        
        # Multiple tokens analysis
        meme_tokens = [
            "BONK/USD",
            "MYRO/USD",
            "WIF/USD",
            "POPCAT/USD"
        ]
        
        analyze_multiple_tokens(
            symbols=meme_tokens,
            output_dir="output/batch",
            days=30
        )
        
    except Exception as e:
        logger.error(f"Error in main execution: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
