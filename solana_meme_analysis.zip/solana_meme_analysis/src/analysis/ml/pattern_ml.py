"""
Machine learning models for pattern recognition in cryptocurrency price data.
"""
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
import logging
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from ...config.settings import PATTERN_RECOGNITION, MODEL_SETTINGS

logger = logging.getLogger(__name__)

class PatternML:
    """Machine learning models for cryptocurrency pattern recognition."""
    
    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize the ML models for pattern recognition.
        
        Args:
            config: Optional configuration dictionary to override default settings
        """
        self.config = {
            'pattern': PATTERN_RECOGNITION['machine_learning'],
            'model': MODEL_SETTINGS['lstm']
        }
        if config:
            self.config.update(config)
            
        self.isolation_forest = None
        self.kmeans = None
        self.lstm_model = None
        self.scaler = StandardScaler()
        
    def prepare_features(
        self,
        df: pd.DataFrame,
        sequence_length: int = 50
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Prepare features for ML models.
        
        Args:
            df: DataFrame containing price and technical indicators
            sequence_length: Length of sequences for LSTM
            
        Returns:
            Tuple of (X features, y labels)
        """
        try:
            features = []
            
            # Technical indicators
            if 'rsi' in df.columns:
                features.append(df['rsi'])
            if 'macd' in df.columns:
                features.append(df['macd'])
            if 'volume' in df.columns:
                features.append(df['volume'])
            if 'returns' in df.columns:
                features.append(df['returns'])
                
            # Price data
            features.extend([
                df['close'],
                df['high'],
                df['low']
            ])
            
            # Stack features
            X = np.column_stack(features)
            
            # Scale features
            X_scaled = self.scaler.fit_transform(X)
            
            # Create sequences for LSTM
            X_seq = []
            y = []
            
            for i in range(len(X_scaled) - sequence_length):
                X_seq.append(X_scaled[i:(i + sequence_length)])
                # Label is 1 if price goes up, 0 if down
                y.append(
                    1 if df['close'].iloc[i + sequence_length] >
                    df['close'].iloc[i + sequence_length - 1] else 0
                )
                
            return np.array(X_seq), np.array(y)
            
        except Exception as e:
            logger.error(f"Error preparing features: {str(e)}")
            raise
            
    def train_anomaly_detector(self, df: pd.DataFrame) -> None:
        """
        Train Isolation Forest for anomaly detection.
        
        Args:
            df: DataFrame containing price and technical indicators
        """
        try:
            # Prepare features
            features = self.prepare_features(df)[0]
            
            # Initialize and train Isolation Forest
            self.isolation_forest = IsolationForest(
                contamination=self.config['pattern']['isolation_forest']['contamination'],
                random_state=self.config['pattern']['isolation_forest']['random_state']
            )
            
            self.isolation_forest.fit(features.reshape(features.shape[0], -1))
            
            logger.info("Anomaly detector trained successfully")
            
        except Exception as e:
            logger.error(f"Error training anomaly detector: {str(e)}")
            raise
            
    def detect_anomalies(self, df: pd.DataFrame) -> np.ndarray:
        """
        Detect anomalies in price patterns.
        
        Args:
            df: DataFrame containing price and technical indicators
            
        Returns:
            Array of anomaly scores (-1 for anomalies, 1 for normal patterns)
        """
        try:
            if self.isolation_forest is None:
                raise ValueError("Anomaly detector not trained")
                
            features = self.prepare_features(df)[0]
            return self.isolation_forest.predict(features.reshape(features.shape[0], -1))
            
        except Exception as e:
            logger.error(f"Error detecting anomalies: {str(e)}")
            raise
            
    def train_pattern_classifier(
        self,
        df: pd.DataFrame,
        labels: np.ndarray
    ) -> None:
        """
        Train LSTM model for pattern classification.
        
        Args:
            df: DataFrame containing price and technical indicators
            labels: Array of pattern labels
        """
        try:
            # Prepare sequences
            X, y = self.prepare_features(df)
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(
                X, y,
                test_size=0.2,
                random_state=42
            )
            
            # Build LSTM model
            self.lstm_model = Sequential([
                LSTM(
                    self.config['model']['hidden_layers'][0],
                    input_shape=(X.shape[1], X.shape[2]),
                    return_sequences=True
                ),
                Dropout(self.config['model']['dropout_rate']),
                LSTM(self.config['model']['hidden_layers'][1]),
                Dropout(self.config['model']['dropout_rate']),
                Dense(1, activation='sigmoid')
            ])
            
            # Compile model
            self.lstm_model.compile(
                optimizer='adam',
                loss='binary_crossentropy',
                metrics=['accuracy']
            )
            
            # Train model
            self.lstm_model.fit(
                X_train,
                y_train,
                epochs=MODEL_SETTINGS['local']['epochs'],
                batch_size=MODEL_SETTINGS['local']['batch_size'],
                validation_data=(X_test, y_test),
                verbose=1
            )
            
            logger.info("Pattern classifier trained successfully")
            
        except Exception as e:
            logger.error(f"Error training pattern classifier: {str(e)}")
            raise
            
    def predict_patterns(self, df: pd.DataFrame) -> np.ndarray:
        """
        Predict patterns using trained LSTM model.
        
        Args:
            df: DataFrame containing price and technical indicators
            
        Returns:
            Array of pattern predictions
        """
        try:
            if self.lstm_model is None:
                raise ValueError("Pattern classifier not trained")
                
            X, _ = self.prepare_features(df)
            return self.lstm_model.predict(X)
            
        except Exception as e:
            logger.error(f"Error predicting patterns: {str(e)}")
            raise
            
    def cluster_patterns(self, df: pd.DataFrame, n_clusters: int = 5) -> np.ndarray:
        """
        Cluster similar price patterns.
        
        Args:
            df: DataFrame containing price and technical indicators
            n_clusters: Number of clusters to identify
            
        Returns:
            Array of cluster labels
        """
        try:
            # Prepare features
            features = self.prepare_features(df)[0]
            
            # Initialize and fit KMeans
            self.kmeans = KMeans(
                n_clusters=n_clusters,
                random_state=self.config['pattern']['clustering']['random_state']
            )
            
            return self.kmeans.fit_predict(features.reshape(features.shape[0], -1))
            
        except Exception as e:
            logger.error(f"Error clustering patterns: {str(e)}")
            raise
            
    def analyze_pattern_sequence(
        self,
        df: pd.DataFrame,
        window_size: int = 10
    ) -> List[Dict]:
        """
        Analyze sequence of patterns for trend prediction.
        
        Args:
            df: DataFrame containing price and technical indicators
            window_size: Size of rolling window for analysis
            
        Returns:
            List of pattern sequences with predictions
        """
        try:
            # Get predictions
            predictions = self.predict_patterns(df)
            
            # Analyze sequences
            sequences = []
            for i in range(len(predictions) - window_size):
                sequence = predictions[i:i + window_size]
                
                # Calculate sequence metrics
                trend_strength = np.mean(sequence)
                trend_consistency = 1 - np.std(sequence)
                
                sequences.append({
                    'start_idx': i,
                    'end_idx': i + window_size,
                    'trend_strength': float(trend_strength),
                    'trend_consistency': float(trend_consistency),
                    'prediction': float(predictions[i + window_size])
                })
                
            return sequences
            
        except Exception as e:
            logger.error(f"Error analyzing pattern sequence: {str(e)}")
            raise
            
    def evaluate_model_performance(
        self,
        df: pd.DataFrame,
        test_size: float = 0.2
    ) -> Dict:
        """
        Evaluate model performance metrics.
        
        Args:
            df: DataFrame containing price and technical indicators
            test_size: Proportion of data to use for testing
            
        Returns:
            Dictionary of performance metrics
        """
        try:
            # Prepare data
            X, y = self.prepare_features(df)
            X_train, X_test, y_train, y_test = train_test_split(
                X, y,
                test_size=test_size,
                random_state=42
            )
            
            # Get predictions
            y_pred = self.lstm_model.predict(X_test)
            y_pred_binary = (y_pred > 0.5).astype(int)
            
            # Calculate metrics
            accuracy = np.mean(y_pred_binary == y_test)
            precision = np.sum((y_pred_binary == 1) & (y_test == 1)) / np.sum(y_pred_binary == 1)
            recall = np.sum((y_pred_binary == 1) & (y_test == 1)) / np.sum(y_test == 1)
            f1_score = 2 * (precision * recall) / (precision + recall)
            
            return {
                'accuracy': float(accuracy),
                'precision': float(precision),
                'recall': float(recall),
                'f1_score': float(f1_score)
            }
            
        except Exception as e:
            logger.error(f"Error evaluating model performance: {str(e)}")
            raise
