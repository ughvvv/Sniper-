"""
Historical price and social data analysis for Solana meme coins.
"""
import logging
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
from pathlib import Path
from .pattern_recognition import PatternRecognition
from ...collectors.market.order_book_collector import OrderBookCollector

logger = logging.getLogger(__name__)

class HistoricalAnalysis:
    """Analyzes historical price and social data for meme coins."""
    
    def __init__(self, data_dir: Path, config: Optional[Dict] = None):
        """
        Initialize the historical analysis.
        
        Args:
            data_dir: Directory containing historical data files
            config: Configuration dictionary for analysis parameters
        """
        self.data_dir = data_dir
        self.config = config or {}
        self.pattern_recognition = PatternRecognition(self.config)
        self.order_book_collector = OrderBookCollector(self.config)
    
    def load_historical_data(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> pd.DataFrame:
        """
        Load and combine historical data from CSV files.
        
        Args:
            start_date: Start date for filtering data
            end_date: End date for filtering data
            
        Returns:
            DataFrame containing combined historical data
        """
        try:
            # Find all CSV files in data directory
            csv_files = list(self.data_dir.glob('top_memecoins_*.csv'))
            
            if not csv_files:
                logger.warning("No historical data files found")
                return pd.DataFrame()
            
            # Load and combine all CSV files
            dfs = []
            for file in csv_files:
                try:
                    # Extract timestamp from filename
                    timestamp_str = file.stem.split('_')[-2:]
                    timestamp = datetime.strptime('_'.join(timestamp_str), '%Y%m%d_%H%M%S')
                    
                    if start_date and timestamp < start_date:
                        continue
                    if end_date and timestamp > end_date:
                        continue
                    
                    df = pd.read_csv(file)
                    df['snapshot_date'] = timestamp
                    dfs.append(df)
                    
                except Exception as e:
                    logger.error(f"Error loading file {file}: {str(e)}")
                    continue
            
            if not dfs:
                return pd.DataFrame()
            
            combined_df = pd.concat(dfs, ignore_index=True)
            combined_df.sort_values('snapshot_date', inplace=True)
            return combined_df
            
        except Exception as e:
            logger.error(f"Error loading historical data: {str(e)}")
            return pd.DataFrame()
    
    async def analyze_performance_trends(
        self,
        df: pd.DataFrame,
        min_snapshots: int = 2
    ) -> Dict:
        """
        Analyze performance trends across multiple snapshots.
        
        Args:
            df: DataFrame containing historical data
            min_snapshots: Minimum number of snapshots required for analysis
            
        Returns:
            Dictionary containing trend analysis results
        """
        try:
            # Group by token address and analyze trends
            token_stats = []
            
            for address in df['address'].unique():
                token_data = df[df['address'] == address].sort_values('snapshot_date')
                
                if len(token_data) < min_snapshots:
                    continue
                
                # Prepare OHLCV data for pattern recognition
                ohlcv_data = self._prepare_ohlcv_data(token_data)
                
                # Analyze breakout patterns
                breakout_patterns = self.pattern_recognition.analyze_breakout_patterns(
                    ohlcv_data
                )
                
                # Calculate performance metrics
                price_changes = token_data['price_change_percent'].tolist()
                volume_changes = token_data['volume_24h'].pct_change().fillna(0).tolist()
                liquidity_changes = token_data['liquidity'].pct_change().fillna(0).tolist()
                
                # Analyze wallet activity
                wallet_activity = self._analyze_wallet_activity(token_data)
                
                # Analyze trading patterns
                trading_patterns = self._analyze_trading_patterns(token_data)
                
                # Social media growth
                social_growth = self._analyze_social_growth(token_data)
                
                # Collect and analyze order book data
                order_book_metrics = await self._analyze_order_book_metrics(
                    address,
                    token_data['snapshot_date'].min(),
                    token_data['snapshot_date'].max()
                )
                
                # Market depth analysis with order book insights
                market_depth = self._analyze_market_depth(token_data, order_book_metrics)
                
                token_stats.append({
                    'address': address,
                    'symbol': token_data['symbol'].iloc[0],
                    'name': token_data['name'].iloc[0],
                    'description': token_data['description'].iloc[0],
                    'logo_uri': token_data['logo_uri'].iloc[0],
                    
                    # Price and volume trends
                    'price_trend': self._calculate_trend(price_changes),
                    'volume_trend': self._calculate_trend(volume_changes),
                    'liquidity_trend': self._calculate_trend(liquidity_changes),
                    'volatility': float(token_data['volatility'].mean()),
                    'max_drawdown': float(token_data['max_drawdown'].mean()),
                    
                    # Breakout patterns
                    'breakout_patterns': breakout_patterns,
                    'pattern_count': len(breakout_patterns),
                    'avg_pattern_confidence': np.mean([
                        p['confidence_score'] for p in breakout_patterns
                    ]) if breakout_patterns else 0,
                    
                    # Wallet and trading activity
                    **wallet_activity,
                    **trading_patterns,
                    
                    # Market depth metrics with order book data
                    **market_depth,
                    
                    # Order book specific metrics
                    **order_book_metrics,
                    
                    # Social metrics
                    'social_presence_score': self._calculate_social_score(token_data.iloc[-1]),
                    **social_growth
                })
            
            # Calculate market-wide statistics
            market_stats = {
                'total_tokens_analyzed': len(token_stats),
                'positive_trend_count': sum(1 for t in token_stats if t['price_trend'] > 0),
                'negative_trend_count': sum(1 for t in token_stats if t['price_trend'] < 0),
                'avg_social_presence': np.mean([t['social_presence_score'] for t in token_stats]),
                'avg_wallet_retention': np.mean([t['wallet_retention_rate'] for t in token_stats]),
                'avg_buy_sell_ratio': np.mean([t['buy_sell_ratio'] for t in token_stats]),
                
                # Order book statistics
                'avg_bid_ask_spread': np.mean([t['avg_bid_ask_spread'] for t in token_stats]),
                'avg_order_book_depth': np.mean([t['avg_order_book_depth'] for t in token_stats]),
                'avg_liquidity_imbalance': np.mean([t['liquidity_imbalance'] for t in token_stats]),
                
                # Pattern analysis statistics
                'total_patterns_identified': sum(t['pattern_count'] for t in token_stats),
                'avg_pattern_confidence': np.mean([
                    t['avg_pattern_confidence'] for t in token_stats if t['pattern_count'] > 0
                ]),
                'tokens_with_patterns': sum(1 for t in token_stats if t['pattern_count'] > 0),
                'high_confidence_patterns': sum(
                    1 for t in token_stats 
                    for p in t['breakout_patterns'] 
                    if p['confidence_score'] >= 0.9
                ),
                
                # Top performers in different categories
                'top_performers': sorted(
                    token_stats,
                    key=lambda x: x['price_trend'],
                    reverse=True
                )[:10],
                'top_pattern_quality': sorted(
                    [t for t in token_stats if t['pattern_count'] > 0],
                    key=lambda x: x['avg_pattern_confidence'],
                    reverse=True
                )[:10],
                'top_social_growth': sorted(
                    token_stats,
                    key=lambda x: x['social_growth_score'],
                    reverse=True
                )[:10],
                'most_active_trading': sorted(
                    token_stats,
                    key=lambda x: x['trading_activity_score'],
                    reverse=True
                )[:10],
                'best_liquidity_profile': sorted(
                    token_stats,
                    key=lambda x: x['liquidity_score'],
                    reverse=True
                )[:10]
            }
            
            return market_stats
            
        except Exception as e:
            logger.error(f"Error analyzing performance trends: {str(e)}")
            return {}
    
    async def _analyze_order_book_metrics(
        self,
        token_address: str,
        start_time: datetime,
        end_time: datetime
    ) -> Dict:
        """Analyze order book metrics for a token."""
        try:
            # Collect order book data
            order_book_data = await self.order_book_collector.collect_order_book_data(
                token_address,
                start_time,
                end_time,
                depth=10,  # Get top 10 levels
                interval='1h'  # 1-hour intervals
            )
            
            if order_book_data.empty:
                return self._get_default_order_book_metrics()
            
            # Calculate bid-ask spread over time
            spreads = []
            depths = []
            imbalances = []
            
            for timestamp in order_book_data['timestamp'].unique():
                time_data = order_book_data[order_book_data['timestamp'] == timestamp]
                
                # Get best bid and ask
                best_bid = time_data[
                    (time_data['side'] == 'bid') & (time_data['level'] == 1)
                ]['price'].iloc[0]
                best_ask = time_data[
                    (time_data['side'] == 'ask') & (time_data['level'] == 1)
                ]['price'].iloc[0]
                
                # Calculate spread
                spread = (best_ask - best_bid) / best_bid * 100
                spreads.append(spread)
                
                # Calculate depth (total volume in order book)
                total_depth = time_data['size'].sum()
                depths.append(total_depth)
                
                # Calculate bid/ask imbalance
                bid_volume = time_data[time_data['side'] == 'bid']['size'].sum()
                ask_volume = time_data[time_data['side'] == 'ask']['size'].sum()
                imbalance = (bid_volume - ask_volume) / (bid_volume + ask_volume)
                imbalances.append(imbalance)
            
            # Calculate liquidity score based on depth and spread
            avg_depth = np.mean(depths)
            avg_spread = np.mean(spreads)
            liquidity_score = (
                (np.log10(avg_depth) * 0.7) - 
                (avg_spread * 0.3)
            ) if avg_depth > 0 else 0
            
            return {
                'avg_bid_ask_spread': float(np.mean(spreads)),
                'min_bid_ask_spread': float(np.min(spreads)),
                'max_bid_ask_spread': float(np.max(spreads)),
                'spread_volatility': float(np.std(spreads)),
                
                'avg_order_book_depth': float(np.mean(depths)),
                'depth_trend': float(self._calculate_trend(depths)),
                
                'liquidity_imbalance': float(np.mean(imbalances)),
                'imbalance_volatility': float(np.std(imbalances)),
                
                'liquidity_score': float(liquidity_score),
                
                # Additional metrics for market making analysis
                'spread_stability': float(1 - (np.std(spreads) / np.mean(spreads)))
                if np.mean(spreads) > 0 else 0,
                'depth_stability': float(1 - (np.std(depths) / np.mean(depths)))
                if np.mean(depths) > 0 else 0
            }
            
        except Exception as e:
            logger.error(f"Error analyzing order book metrics: {str(e)}")
            return self._get_default_order_book_metrics()
    
    @staticmethod
    def _get_default_order_book_metrics() -> Dict:
        """Return default values for order book metrics."""
        return {
            'avg_bid_ask_spread': 0.0,
            'min_bid_ask_spread': 0.0,
            'max_bid_ask_spread': 0.0,
            'spread_volatility': 0.0,
            'avg_order_book_depth': 0.0,
            'depth_trend': 0.0,
            'liquidity_imbalance': 0.0,
            'imbalance_volatility': 0.0,
            'liquidity_score': 0.0,
            'spread_stability': 0.0,
            'depth_stability': 0.0
        }
    
    def _analyze_market_depth(
        self,
        token_data: pd.DataFrame,
        order_book_metrics: Dict
    ) -> Dict:
        """Analyze market depth and liquidity metrics."""
        try:
            latest = token_data.iloc[-1]
            
            # Calculate market concentration
            supply_concentration = (
                latest['holder_count'] / latest['circulating_supply']
                if latest['circulating_supply'] > 0 else 0
            )
            
            # Calculate market maturity score incorporating order book metrics
            maturity_score = (
                (np.log10(latest['number_markets']) * 0.2) +
                (np.log10(latest['holder_count']) * 0.3) +
                (np.log10(latest['liquidity']) * 0.2) +
                (order_book_metrics['spread_stability'] * 0.15) +
                (order_book_metrics['depth_stability'] * 0.15)
            ) if all(v > 0 for v in [latest['number_markets'], 
                                   latest['holder_count'], 
                                   latest['liquidity']]) else 0
            
            # Calculate liquidity quality score
            liquidity_quality = (
                (1 / (1 + order_book_metrics['avg_bid_ask_spread'])) * 0.4 +
                (order_book_metrics['depth_stability'] * 0.3) +
                (order_book_metrics['spread_stability'] * 0.3)
            )
            
            return {
                'supply_concentration': float(supply_concentration),
                'market_maturity_score': float(maturity_score),
                'liquidity_quality_score': float(liquidity_quality),
                'avg_liquidity_per_market': float(latest['liquidity'] / latest['number_markets'])
                if latest['number_markets'] > 0 else 0
            }
        except Exception as e:
            logger.error(f"Error analyzing market depth: {str(e)}")
            return {}

    # ... (rest of the existing methods remain unchanged)
