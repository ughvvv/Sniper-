"""
Launch period analysis for meme coins with Solana correlation.
"""
import logging
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
from scipy import stats
from dataclasses import dataclass

logger = logging.getLogger(__name__)

@dataclass
class LaunchMetrics:
    """Metrics for token launch period analysis."""
    launch_date: datetime
    initial_price: float
    peak_price: float
    time_to_peak: timedelta
    price_increase: float
    volume_profile: List[float]
    volatility: float
    correlation_with_sol: float
    beta_with_sol: float
    relative_strength: float
    launch_momentum: float
    price_discovery_phase: int  # hours until price stabilization
    success_score: float
    granular_metrics: Dict[str, Dict]  # Stores metrics for different time intervals

class LaunchAnalyzer:
    """Analyzes token performance during launch period and correlation with Solana."""
    
    def __init__(self, price_collector):
        """
        Initialize launch analyzer.
        
        Args:
            price_collector: PriceDataCollector instance for fetching data
        """
        self.price_collector = price_collector
        self.sol_address = "So11111111111111111111111111111111111111112"
        self.time_intervals = ['30m', '1h', '2h', '4h', '8h', '24h']
    
    async def analyze_launch_period(
        self,
        token_address: str,
        launch_date: Optional[datetime] = None
    ) -> LaunchMetrics:
        """
        Analyze token's launch period (first 10 days).
        
        Args:
            token_address: Token contract address
            launch_date: Known launch date (if None, will be detected)
            
        Returns:
            LaunchMetrics containing analysis results
        """
        try:
            # Detect launch date if not provided
            if not launch_date:
                launch_date = await self._detect_launch_date(token_address)
            
            end_date = launch_date + timedelta(days=10)
            current_date = datetime.utcnow()
            if end_date > current_date:
                end_date = current_date
            
            # Fetch token and SOL data concurrently for the period
            token_data, sol_data = await self._fetch_comparative_data(
                token_address,
                launch_date,
                end_date
            )
            
            if token_data.empty:
                raise ValueError("No token data available")
            
            # Calculate granular metrics for each time interval
            granular_metrics = self._calculate_granular_metrics(token_data, sol_data)
            
            # Calculate launch metrics
            initial_price = token_data['close'].iloc[0]
            peak_price = token_data['high'].max()
            peak_idx = token_data['high'].idxmax()
            time_to_peak = peak_idx - launch_date
            price_increase = (peak_price - initial_price) / initial_price * 100
            
            # Calculate volume profile
            volume_profile = self._calculate_volume_profile(token_data)
            
            # Calculate volatility using granular data
            volatility = self._calculate_adaptive_volatility(granular_metrics)
            
            # Calculate correlation with SOL using multiple timeframes
            correlation, beta = self._calculate_sol_relationship(
                token_data,
                sol_data,
                granular_metrics
            )
            
            # Calculate relative strength
            relative_strength = self._calculate_relative_strength(
                token_data,
                sol_data,
                granular_metrics
            )
            
            # Calculate launch momentum using granular data
            launch_momentum = self._calculate_launch_momentum(
                token_data,
                granular_metrics
            )
            
            # Determine price discovery phase
            price_discovery_hours = self._calculate_price_discovery_phase(
                token_data,
                granular_metrics
            )
            
            # Calculate overall success score
            success_score = self._calculate_success_score(
                price_increase,
                volume_profile,
                volatility,
                correlation,
                launch_momentum,
                price_discovery_hours,
                granular_metrics
            )
            
            return LaunchMetrics(
                launch_date=launch_date,
                initial_price=initial_price,
                peak_price=peak_price,
                time_to_peak=time_to_peak,
                price_increase=price_increase,
                volume_profile=volume_profile,
                volatility=volatility,
                correlation_with_sol=correlation,
                beta_with_sol=beta,
                relative_strength=relative_strength,
                launch_momentum=launch_momentum,
                price_discovery_phase=price_discovery_hours,
                success_score=success_score,
                granular_metrics=granular_metrics
            )
            
        except Exception as e:
            logger.error(f"Error analyzing launch period: {str(e)}")
            raise
    
    def _calculate_granular_metrics(
        self,
        token_data: pd.DataFrame,
        sol_data: pd.DataFrame
    ) -> Dict[str, Dict]:
        """Calculate metrics for different time intervals."""
        metrics = {}
        
        for interval in self.time_intervals:
            metrics[interval] = {
                'price_changes': self._calculate_interval_price_changes(
                    token_data, interval
                ),
                'volume_profile': self._calculate_interval_volume_profile(
                    token_data, interval
                ),
                'trade_metrics': self._calculate_interval_trade_metrics(
                    token_data, interval
                ),
                'sol_correlation': self._calculate_interval_correlation(
                    token_data, sol_data, interval
                ),
                'wallet_activity': self._calculate_interval_wallet_activity(
                    token_data, interval
                )
            }
        
        return metrics
    
    def _calculate_interval_price_changes(
        self,
        df: pd.DataFrame,
        interval: str
    ) -> Dict:
        """Calculate price changes for specific interval."""
        try:
            changes = []
            window_size = self._get_window_size(interval)
            
            for i in range(0, len(df), window_size):
                window = df.iloc[i:i+window_size]
                if not window.empty:
                    start_price = window['close'].iloc[0]
                    end_price = window['close'].iloc[-1]
                    change = (end_price - start_price) / start_price * 100
                    changes.append(change)
            
            return {
                'changes': changes,
                'mean': np.mean(changes) if changes else 0,
                'std': np.std(changes) if changes else 0,
                'max': max(changes) if changes else 0,
                'min': min(changes) if changes else 0
            }
        except Exception as e:
            logger.error(f"Error calculating interval price changes: {str(e)}")
            return {}
    
    def _calculate_interval_volume_profile(
        self,
        df: pd.DataFrame,
        interval: str
    ) -> Dict:
        """Calculate volume profile for specific interval."""
        try:
            window_size = self._get_window_size(interval)
            volumes = []
            
            for i in range(0, len(df), window_size):
                window = df.iloc[i:i+window_size]
                if not window.empty:
                    volume = window['volume'].sum()
                    volumes.append(volume)
            
            return {
                'volumes': volumes,
                'mean': np.mean(volumes) if volumes else 0,
                'std': np.std(volumes) if volumes else 0,
                'trend': self._calculate_trend(volumes) if volumes else 0
            }
        except Exception as e:
            logger.error(f"Error calculating interval volume profile: {str(e)}")
            return {}
    
    def _calculate_interval_trade_metrics(
        self,
        df: pd.DataFrame,
        interval: str
    ) -> Dict:
        """Calculate trade metrics for specific interval."""
        try:
            window_size = self._get_window_size(interval)
            metrics = []
            
            for i in range(0, len(df), window_size):
                window = df.iloc[i:i+window_size]
                if not window.empty:
                    buy_volume = window.get('volume_buy', 0).sum()
                    sell_volume = window.get('volume_sell', 0).sum()
                    ratio = buy_volume / sell_volume if sell_volume > 0 else 1
                    metrics.append({
                        'buy_volume': buy_volume,
                        'sell_volume': sell_volume,
                        'ratio': ratio
                    })
            
            return {
                'metrics': metrics,
                'avg_ratio': np.mean([m['ratio'] for m in metrics]) if metrics else 1,
                'volume_trend': self._calculate_trend(
                    [m['buy_volume'] + m['sell_volume'] for m in metrics]
                ) if metrics else 0
            }
        except Exception as e:
            logger.error(f"Error calculating interval trade metrics: {str(e)}")
            return {}
    
    def _calculate_interval_correlation(
        self,
        token_data: pd.DataFrame,
        sol_data: pd.DataFrame,
        interval: str
    ) -> Dict:
        """Calculate correlation metrics for specific interval."""
        try:
            window_size = self._get_window_size(interval)
            correlations = []
            betas = []
            
            for i in range(0, len(token_data), window_size):
                token_window = token_data.iloc[i:i+window_size]
                sol_window = sol_data.iloc[i:i+window_size]
                
                if not token_window.empty and not sol_window.empty:
                    token_returns = token_window['close'].pct_change().dropna()
                    sol_returns = sol_window['close'].pct_change().dropna()
                    
                    if len(token_returns) > 1:
                        corr = token_returns.corr(sol_returns)
                        correlations.append(corr)
                        
                        # Calculate beta
                        cov = token_returns.cov(sol_returns)
                        var = sol_returns.var()
                        beta = cov / var if var != 0 else 0
                        betas.append(beta)
            
            return {
                'correlations': correlations,
                'mean_correlation': np.mean(correlations) if correlations else 0,
                'betas': betas,
                'mean_beta': np.mean(betas) if betas else 0,
                'correlation_trend': self._calculate_trend(correlations) if correlations else 0
            }
        except Exception as e:
            logger.error(f"Error calculating interval correlation: {str(e)}")
            return {}
    
    def _calculate_interval_wallet_activity(
        self,
        df: pd.DataFrame,
        interval: str
    ) -> Dict:
        """Calculate wallet activity metrics for specific interval."""
        try:
            window_size = self._get_window_size(interval)
            metrics = []
            
            for i in range(0, len(df), window_size):
                window = df.iloc[i:i+window_size]
                if not window.empty:
                    unique_wallets = window.get('unique_wallets', 0).mean()
                    trade_count = window.get('trades', 0).sum()
                    metrics.append({
                        'unique_wallets': unique_wallets,
                        'trade_count': trade_count,
                        'trades_per_wallet': trade_count / unique_wallets if unique_wallets > 0 else 0
                    })
            
            return {
                'metrics': metrics,
                'avg_unique_wallets': np.mean([m['unique_wallets'] for m in metrics]) if metrics else 0,
                'avg_trades_per_wallet': np.mean([m['trades_per_wallet'] for m in metrics]) if metrics else 0,
                'wallet_growth': self._calculate_trend([m['unique_wallets'] for m in metrics]) if metrics else 0
            }
        except Exception as e:
            logger.error(f"Error calculating interval wallet activity: {str(e)}")
            return {}
    
    def _calculate_adaptive_volatility(self, granular_metrics: Dict) -> float:
        """Calculate adaptive volatility using multiple timeframes."""
        try:
            volatilities = []
            weights = {
                '30m': 0.3,
                '1h': 0.25,
                '2h': 0.2,
                '4h': 0.15,
                '8h': 0.07,
                '24h': 0.03
            }
            
            for interval, weight in weights.items():
                if interval in granular_metrics:
                    price_changes = granular_metrics[interval]['price_changes']
                    if 'std' in price_changes:
                        volatilities.append(price_changes['std'] * weight)
            
            return sum(volatilities) if volatilities else 0
            
        except Exception as e:
            logger.error(f"Error calculating adaptive volatility: {str(e)}")
            return 0
    
    @staticmethod
    def _get_window_size(interval: str) -> int:
        """Convert interval string to number of minutes."""
        try:
            if interval.endswith('m'):
                return int(interval[:-1])
            elif interval.endswith('h'):
                return int(interval[:-1]) * 60
            else:
                return 60  # default to 1 hour
        except:
            return 60
    
    @staticmethod
    def _calculate_trend(values: List[float]) -> float:
        """Calculate trend direction and strength."""
        if not values or len(values) < 2:
            return 0
        
        try:
            x = np.arange(len(values))
            y = np.array(values)
            slope, _ = np.polyfit(x, y, 1)
            return slope
        except:
            return 0
