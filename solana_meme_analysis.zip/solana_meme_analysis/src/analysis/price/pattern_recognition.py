"""
Advanced pattern recognition and ML-based analysis for price movements.
"""
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
import logging
from datetime import datetime
from ...config.settings import PATTERN_RECOGNITION
from ...utils.data_validation import DataValidator
from ...utils.visualization import PatternVisualizer
from ..ml.pattern_ml import PatternML
from pathlib import Path

logger = logging.getLogger(__name__)

class PatternRecognition:
    """Advanced pattern recognition for cryptocurrency price analysis."""
    
    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize pattern recognition with configuration.
        
        Args:
            config: Configuration dictionary containing analysis parameters
        """
        self.config = PATTERN_RECOGNITION
        if config:
            self.config.update(config)
            
        # Initialize components
        self.data_validator = DataValidator()
        self.visualizer = PatternVisualizer()
        self.ml_analyzer = PatternML()
        
    def analyze_breakout_patterns(
        self,
        df: pd.DataFrame,
        save_visualizations: bool = True,
        output_dir: Optional[str] = None
    ) -> Tuple[List[Dict], Dict[str, str]]:
        """
        Identify potential breakout patterns using multiple technical indicators
        and machine learning models.
        
        Args:
            df: DataFrame with OHLCV data
            save_visualizations: Whether to save visualization plots
            output_dir: Directory to save visualizations
            
        Returns:
            Tuple of (identified patterns, visualization paths)
        """
        try:
            # Validate and prepare data
            df_processed, is_valid, messages = self.data_validator.validate_and_prepare_data(
                df,
                remove_outliers=True,
                normalize=True
            )
            
            if not is_valid:
                logger.error(f"Data validation failed: {messages}")
                return [], {}
                
            # Calculate technical indicators
            df_processed = self._calculate_technical_indicators(df_processed)
            
            # Train ML models
            self.ml_analyzer.train_anomaly_detector(df_processed)
            
            # Identify potential breakout zones
            breakout_zones = self._identify_breakout_zones(df_processed)
            
            # Validate patterns with volume profile and ML
            validated_patterns = self._validate_patterns(df_processed, breakout_zones)
            
            # Calculate pattern confidence scores
            patterns_with_confidence = self._calculate_pattern_confidence(
                df_processed,
                validated_patterns
            )
            
            # Filter by confidence threshold
            high_confidence_patterns = [
                pattern for pattern in patterns_with_confidence
                if pattern['confidence_score'] >= self.config['breakout']['confidence_threshold']
            ]
            
            # Generate visualizations
            visualization_paths = {}
            if save_visualizations and output_dir:
                visualization_paths = self._generate_visualizations(
                    df_processed,
                    high_confidence_patterns,
                    output_dir
                )
                
            return high_confidence_patterns, visualization_paths
            
        except Exception as e:
            logger.error(f"Error in breakout pattern analysis: {str(e)}")
            return [], {}
            
    def _calculate_technical_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate advanced technical indicators for pattern recognition."""
        try:
            # Convert price columns to numpy arrays
            high = df['high'].values
            low = df['low'].values
            close = df['close'].values
            volume = df['volume'].values
            
            # Calculate indicators using vectorized operations
            df['returns'] = pd.Series(close).pct_change()
            df['log_returns'] = np.log(close).diff()
            
            # Momentum indicators
            df['rsi'] = self._calculate_rsi(close)
            df['macd'], df['macd_signal'] = self._calculate_macd(close)
            
            # Volatility indicators
            df['atr'] = self._calculate_atr(high, low, close)
            df['bollinger_upper'], df['bollinger_middle'], df['bollinger_lower'] = \
                self._calculate_bollinger_bands(close)
            
            # Volume indicators
            df['obv'] = self._calculate_obv(close, volume)
            df['mfi'] = self._calculate_mfi(high, low, close, volume)
            
            # Trend indicators
            df['adx'] = self._calculate_adx(high, low, close)
            
            # Custom indicators
            df['price_volatility'] = self._calculate_adaptive_volatility(df)
            df['volume_profile'] = self._calculate_volume_profile(df)
            df['support_resistance'] = self._identify_support_resistance(df)
            
            return df
            
        except Exception as e:
            logger.error(f"Error calculating technical indicators: {str(e)}")
            raise
            
    def _calculate_rsi(self, close: np.ndarray, period: int = 14) -> np.ndarray:
        """Calculate RSI using vectorized operations."""
        delta = np.diff(close)
        gain = np.where(delta > 0, delta, 0)
        loss = np.where(delta < 0, -delta, 0)
        
        avg_gain = np.concatenate(([np.nan], pd.Series(gain).rolling(period).mean()))
        avg_loss = np.concatenate(([np.nan], pd.Series(loss).rolling(period).mean()))
        
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        return rsi
        
    def _calculate_macd(
        self,
        close: np.ndarray,
        fast: int = 12,
        slow: int = 26,
        signal: int = 9
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Calculate MACD using vectorized operations."""
        ema_fast = pd.Series(close).ewm(span=fast, adjust=False).mean()
        ema_slow = pd.Series(close).ewm(span=slow, adjust=False).mean()
        
        macd = ema_fast - ema_slow
        macd_signal = macd.ewm(span=signal, adjust=False).mean()
        
        return macd.values, macd_signal.values
        
    def _calculate_atr(
        self,
        high: np.ndarray,
        low: np.ndarray,
        close: np.ndarray,
        period: int = 14
    ) -> np.ndarray:
        """Calculate ATR using vectorized operations."""
        high_low = high - low
        high_close = np.abs(high - np.roll(close, 1))
        low_close = np.abs(low - np.roll(close, 1))
        
        ranges = np.vstack([high_low, high_close, low_close])
        true_range = np.max(ranges, axis=0)
        
        atr = pd.Series(true_range).rolling(period).mean()
        return atr.values
        
    def _calculate_bollinger_bands(
        self,
        close: np.ndarray,
        period: int = 20,
        std_dev: float = 2.0
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Calculate Bollinger Bands using vectorized operations."""
        middle = pd.Series(close).rolling(period).mean()
        std = pd.Series(close).rolling(period).std()
        
        upper = middle + (std * std_dev)
        lower = middle - (std * std_dev)
        
        return upper.values, middle.values, lower.values
        
    def _calculate_obv(self, close: np.ndarray, volume: np.ndarray) -> np.ndarray:
        """Calculate On-Balance Volume using vectorized operations."""
        close_diff = np.diff(close)
        obv = np.zeros_like(volume)
        obv[1:] = np.where(close_diff > 0, volume[1:],
                          np.where(close_diff < 0, -volume[1:], 0))
        return np.cumsum(obv)
        
    def _calculate_mfi(
        self,
        high: np.ndarray,
        low: np.ndarray,
        close: np.ndarray,
        volume: np.ndarray,
        period: int = 14
    ) -> np.ndarray:
        """Calculate Money Flow Index using vectorized operations."""
        typical_price = (high + low + close) / 3
        money_flow = typical_price * volume
        
        positive_flow = np.where(typical_price > np.roll(typical_price, 1),
                               money_flow, 0)
        negative_flow = np.where(typical_price < np.roll(typical_price, 1),
                               money_flow, 0)
        
        positive_mf = pd.Series(positive_flow).rolling(period).sum()
        negative_mf = pd.Series(negative_flow).rolling(period).sum()
        
        mfi = 100 - (100 / (1 + (positive_mf / negative_mf)))
        return mfi.values
        
    def _calculate_adx(
        self,
        high: np.ndarray,
        low: np.ndarray,
        close: np.ndarray,
        period: int = 14
    ) -> np.ndarray:
        """Calculate ADX using vectorized operations."""
        plus_dm = np.where((high - np.roll(high, 1)) > (np.roll(low, 1) - low),
                          np.maximum(high - np.roll(high, 1), 0), 0)
        minus_dm = np.where((np.roll(low, 1) - low) > (high - np.roll(high, 1)),
                           np.maximum(np.roll(low, 1) - low, 0), 0)
        
        tr = self._calculate_atr(high, low, close, period)
        plus_di = 100 * pd.Series(plus_dm).rolling(period).mean() / tr
        minus_di = 100 * pd.Series(minus_dm).rolling(period).mean() / tr
        
        dx = 100 * np.abs(plus_di - minus_di) / (plus_di + minus_di)
        adx = pd.Series(dx).rolling(period).mean()
        return adx.values
        
    def _identify_breakout_zones(self, df: pd.DataFrame) -> List[Dict]:
        """Identify potential breakout zones using multiple criteria."""
        try:
            breakout_zones = []
            
            # Get anomaly scores from ML model
            anomaly_scores = self.ml_analyzer.detect_anomalies(df)
            
            for i in range(50, len(df)):
                window = df.iloc[i-50:i]
                current = df.iloc[i]
                
                # Check multiple breakout criteria
                price_breakout = self._check_price_breakout(window, current)
                volume_breakout = self._check_volume_breakout(window, current)
                momentum_confirmation = self._check_momentum_confirmation(window, current)
                
                # Consider ML anomaly detection
                is_anomaly = anomaly_scores[i] == -1
                
                if price_breakout and volume_breakout and momentum_confirmation and is_anomaly:
                    breakout_zones.append({
                        'index': i,
                        'timestamp': df.index[i],
                        'price': current['close'],
                        'volume': current['volume'],
                        'breakout_type': 'bullish' if price_breakout > 0 else 'bearish',
                        'anomaly_score': float(anomaly_scores[i])
                    })
                    
            return breakout_zones
            
        except Exception as e:
            logger.error(f"Error identifying breakout zones: {str(e)}")
            raise
            
    def _validate_patterns(
        self,
        df: pd.DataFrame,
        patterns: List[Dict]
    ) -> List[Dict]:
        """Validate patterns using multiple criteria including ML predictions."""
        try:
            validated_patterns = []
            
            # Get ML predictions
            predictions = self.ml_analyzer.predict_patterns(df)
            
            for pattern in patterns:
                idx = pattern['index']
                if idx >= 50:
                    # Analyze volume profile
                    volume_valid = self._validate_volume_profile(
                        df.iloc[idx-50:idx+10]
                    )
                    
                    # Check ML prediction confidence
                    ml_confidence = float(predictions[idx])
                    
                    if volume_valid and ml_confidence > 0.7:
                        pattern['ml_confidence'] = ml_confidence
                        validated_patterns.append(pattern)
                        
            return validated_patterns
            
        except Exception as e:
            logger.error(f"Error validating patterns: {str(e)}")
            raise
            
    def _generate_visualizations(
        self,
        df: pd.DataFrame,
        patterns: List[Dict],
        output_dir: str
    ) -> Dict[str, str]:
        """Generate and save visualization plots."""
        try:
            Path(output_dir).mkdir(parents=True, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            paths = {}
            
            # Price pattern visualization
            price_path = f"{output_dir}/price_patterns_{timestamp}.png"
            self.visualizer.plot_price_pattern(df, patterns, price_path)
            paths['price_pattern'] = price_path
            
            # Candlestick chart
            candlestick_path = f"{output_dir}/candlestick_{timestamp}.png"
            self.visualizer.create_candlestick_chart(df, patterns, candlestick_path)
            paths['candlestick'] = candlestick_path
            
            # Pattern distribution
            if patterns:
                dist_path = f"{output_dir}/pattern_distribution_{timestamp}.png"
                self.visualizer.plot_pattern_distribution(patterns, dist_path)
                paths['distribution'] = dist_path
                
            # Volume profile analysis
            volume_path = f"{output_dir}/volume_profile_{timestamp}.png"
            self.visualizer.plot_volume_profile_analysis(df, patterns, volume_path)
            paths['volume_profile'] = volume_path
            
            return paths
            
        except Exception as e:
            logger.error(f"Error generating visualizations: {str(e)}")
            return {}
