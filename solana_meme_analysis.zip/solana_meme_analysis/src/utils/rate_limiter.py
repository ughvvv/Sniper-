"""
Rate limiter implementation for API requests.
"""
import logging
import time
import asyncio
from collections import deque
from datetime import datetime, timedelta
from typing import Optional

logger = logging.getLogger(__name__)

class RateLimiter:
    """
    Implements a token bucket rate limiter for API requests.
    
    This rate limiter uses a token bucket algorithm to control the rate of
    API requests. It's designed to work with both synchronous and asynchronous code.
    """
    
    def __init__(
        self,
        max_requests: int,
        time_window: int,
        initial_tokens: Optional[int] = None
    ):
        """
        Initialize the rate limiter.
        
        Args:
            max_requests: Maximum number of requests allowed in the time window
            time_window: Time window in seconds
            initial_tokens: Initial number of tokens (defaults to max_requests)
        """
        self.max_requests = max_requests
        self.time_window = time_window
        self.tokens = initial_tokens if initial_tokens is not None else max_requests
        self.requests = deque()
        self.last_update = datetime.utcnow()
    
    async def __aenter__(self):
        """Async context manager entry."""
        await self.acquire()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        pass
    
    def _update_tokens(self):
        """Update the token count based on elapsed time."""
        now = datetime.utcnow()
        time_passed = (now - self.last_update).total_seconds()
        
        # Calculate tokens to add based on time passed
        new_tokens = (time_passed * self.max_requests) / self.time_window
        
        self.tokens = min(self.max_requests, self.tokens + new_tokens)
        self.last_update = now
        
        # Remove old requests from the deque
        while self.requests and self.requests[0] < now - timedelta(seconds=self.time_window):
            self.requests.popleft()
    
    async def acquire(self):
        """
        Acquire a token for making a request.
        
        This method will block until a token is available.
        """
        while True:
            self._update_tokens()
            
            if self.tokens >= 1 and len(self.requests) < self.max_requests:
                self.tokens -= 1
                self.requests.append(datetime.utcnow())
                return
            
            # Calculate wait time
            if self.requests:
                # Wait for the oldest request to expire
                wait_time = (self.requests[0] + timedelta(seconds=self.time_window) - 
                           datetime.utcnow()).total_seconds()
                wait_time = max(0, wait_time)
            else:
                # Wait for a new token
                wait_time = (1 - self.tokens) * (self.time_window / self.max_requests)
            
            logger.debug(f"Rate limit reached. Waiting {wait_time:.2f} seconds")
            await asyncio.sleep(wait_time)
    
    def sync_acquire(self):
        """
        Synchronous version of acquire.
        
        This method will block until a token is available.
        """
        while True:
            self._update_tokens()
            
            if self.tokens >= 1 and len(self.requests) < self.max_requests:
                self.tokens -= 1
                self.requests.append(datetime.utcnow())
                return
            
            # Calculate wait time
            if self.requests:
                # Wait for the oldest request to expire
                wait_time = (self.requests[0] + timedelta(seconds=self.time_window) - 
                           datetime.utcnow()).total_seconds()
                wait_time = max(0, wait_time)
            else:
                # Wait for a new token
                wait_time = (1 - self.tokens) * (self.time_window / self.max_requests)
            
            logger.debug(f"Rate limit reached. Waiting {wait_time:.2f} seconds")
            time.sleep(wait_time)
    
    @property
    def available_tokens(self) -> float:
        """Get the current number of available tokens."""
        self._update_tokens()
        return self.tokens
    
    @property
    def request_count(self) -> int:
        """Get the current number of requests in the window."""
        self._update_tokens()
        return len(self.requests)
    
    def reset(self):
        """Reset the rate limiter to its initial state."""
        self.tokens = self.max_requests
        self.requests.clear()
        self.last_update = datetime.utcnow()

class BatchRateLimiter(RateLimiter):
    """
    Extended rate limiter that supports batch requests.
    
    This version of the rate limiter allows for requesting multiple tokens
    at once, which is useful for batch API operations.
    """
    
    async def acquire_many(self, count: int):
        """
        Acquire multiple tokens for batch requests.
        
        Args:
            count: Number of tokens to acquire
        """
        if count > self.max_requests:
            raise ValueError(
                f"Requested tokens ({count}) exceeds maximum allowed requests "
                f"({self.max_requests})"
            )
        
        while True:
            self._update_tokens()
            
            if (self.tokens >= count and 
                len(self.requests) + count <= self.max_requests):
                self.tokens -= count
                now = datetime.utcnow()
                for _ in range(count):
                    self.requests.append(now)
                return
            
            # Calculate wait time
            if self.requests:
                # Wait for enough old requests to expire
                needed_slots = count - (self.max_requests - len(self.requests))
                if needed_slots > 0:
                    wait_time = (self.requests[needed_slots-1] + 
                               timedelta(seconds=self.time_window) - 
                               datetime.utcnow()).total_seconds()
                    wait_time = max(0, wait_time)
                else:
                    wait_time = 0
            else:
                # Wait for enough tokens
                wait_time = (count - self.tokens) * (self.time_window / self.max_requests)
            
            logger.debug(
                f"Rate limit reached for batch request. "
                f"Waiting {wait_time:.2f} seconds"
            )
            await asyncio.sleep(wait_time)
    
    def sync_acquire_many(self, count: int):
        """
        Synchronous version of acquire_many.
        
        Args:
            count: Number of tokens to acquire
        """
        if count > self.max_requests:
            raise ValueError(
                f"Requested tokens ({count}) exceeds maximum allowed requests "
                f"({self.max_requests})"
            )
        
        while True:
            self._update_tokens()
            
            if (self.tokens >= count and 
                len(self.requests) + count <= self.max_requests):
                self.tokens -= count
                now = datetime.utcnow()
                for _ in range(count):
                    self.requests.append(now)
                return
            
            # Calculate wait time
            if self.requests:
                needed_slots = count - (self.max_requests - len(self.requests))
                if needed_slots > 0:
                    wait_time = (self.requests[needed_slots-1] + 
                               timedelta(seconds=self.time_window) - 
                               datetime.utcnow()).total_seconds()
                    wait_time = max(0, wait_time)
                else:
                    wait_time = 0
            else:
                wait_time = (count - self.tokens) * (self.time_window / self.max_requests)
            
            logger.debug(
                f"Rate limit reached for batch request. "
                f"Waiting {wait_time:.2f} seconds"
            )
            time.sleep(wait_time)
