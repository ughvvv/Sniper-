"""
Data validation and preprocessing utilities for the Solana Meme Analysis project.
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
import logging
from ..config.settings import REQUIRED_COLUMNS, VALIDATION_RULES

logger = logging.getLogger(__name__)

class DataValidator:
    """Handles data validation and preprocessing for analysis."""
    
    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize the data validator.
        
        Args:
            config: Optional configuration dictionary to override default settings
        """
        self.required_columns = REQUIRED_COLUMNS
        self.validation_rules = VALIDATION_RULES
        if config:
            self.validation_rules.update(config)
            
    def validate_dataframe(self, df: pd.DataFrame) -> Tuple[bool, List[str]]:
        """
        Validate input DataFrame against defined rules.
        
        Args:
            df: Input DataFrame to validate
            
        Returns:
            Tuple of (is_valid, list of validation messages)
        """
        messages = []
        is_valid = True
        
        try:
            # Check required columns
            missing_cols = [col for col in self.required_columns if col not in df.columns]
            if missing_cols:
                messages.append(f"Missing required columns: {missing_cols}")
                is_valid = False
                
            # Check minimum data points
            if len(df) < 2:
                messages.append("Insufficient data points for analysis")
                is_valid = False
                
            # Check data types
            if not pd.api.types.is_numeric_dtype(df['close']):
                messages.append("Close prices must be numeric")
                is_valid = False
                
            if not pd.api.types.is_numeric_dtype(df['volume']):
                messages.append("Volume must be numeric")
                is_valid = False
                
            # Check value ranges
            if (df['close'] < self.validation_rules['min_price']).any():
                messages.append("Invalid negative prices detected")
                is_valid = False
                
            if (df['volume'] < self.validation_rules['min_volume']).any():
                messages.append("Invalid negative volumes detected")
                is_valid = False
                
            # Check for missing values
            missing_pct = df[self.required_columns].isnull().mean()
            if (missing_pct > self.validation_rules['max_missing_values']).any():
                messages.append("Too many missing values detected")
                is_valid = False
                
            if is_valid:
                messages.append("Data validation passed successfully")
                
        except Exception as e:
            logger.error(f"Error during data validation: {str(e)}")
            messages.append(f"Validation error: {str(e)}")
            is_valid = False
            
        return is_valid, messages
    
    def preprocess_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Preprocess the DataFrame for analysis.
        
        Args:
            df: Input DataFrame to preprocess
            
        Returns:
            Preprocessed DataFrame
        """
        try:
            # Create a copy to avoid modifying original data
            processed_df = df.copy()
            
            # Sort by timestamp
            if 'timestamp' in processed_df.columns:
                processed_df.sort_values('timestamp', inplace=True)
                
            # Handle missing values
            for col in self.required_columns:
                if col in processed_df.columns:
                    if col in ['volume']:
                        # Fill missing volumes with 0
                        processed_df[col].fillna(0, inplace=True)
                    else:
                        # Forward fill for price data
                        processed_df[col].fillna(method='ffill', inplace=True)
                        # Backward fill any remaining NaNs at the start
                        processed_df[col].fillna(method='bfill', inplace=True)
                        
            # Remove duplicate timestamps
            if 'timestamp' in processed_df.columns:
                processed_df.drop_duplicates(subset=['timestamp'], keep='last', inplace=True)
                
            # Calculate returns and log returns
            processed_df['returns'] = processed_df['close'].pct_change()
            processed_df['log_returns'] = np.log(processed_df['close']).diff()
            
            # Calculate price volatility
            processed_df['volatility'] = processed_df['returns'].rolling(window=20).std()
            
            # Calculate volume moving average
            processed_df['volume_ma'] = processed_df['volume'].rolling(window=20).mean()
            
            # Remove rows with NaN values created by calculations
            processed_df.dropna(inplace=True)
            
            # Reset index
            processed_df.reset_index(drop=True, inplace=True)
            
            return processed_df
            
        except Exception as e:
            logger.error(f"Error during data preprocessing: {str(e)}")
            raise
            
    def remove_outliers(
        self,
        df: pd.DataFrame,
        columns: List[str],
        n_sigmas: float = 3
    ) -> pd.DataFrame:
        """
        Remove outliers from specified columns using the z-score method.
        
        Args:
            df: Input DataFrame
            columns: List of columns to check for outliers
            n_sigmas: Number of standard deviations to use as threshold
            
        Returns:
            DataFrame with outliers removed
        """
        try:
            clean_df = df.copy()
            
            for col in columns:
                if col in clean_df.columns:
                    z_scores = np.abs((clean_df[col] - clean_df[col].mean()) / 
                                    clean_df[col].std())
                    clean_df = clean_df[z_scores < n_sigmas]
                    
            return clean_df
            
        except Exception as e:
            logger.error(f"Error removing outliers: {str(e)}")
            return df
            
    def normalize_data(
        self,
        df: pd.DataFrame,
        columns: List[str],
        method: str = 'zscore'
    ) -> pd.DataFrame:
        """
        Normalize specified columns in the DataFrame.
        
        Args:
            df: Input DataFrame
            columns: List of columns to normalize
            method: Normalization method ('zscore' or 'minmax')
            
        Returns:
            DataFrame with normalized columns
        """
        try:
            normalized_df = df.copy()
            
            for col in columns:
                if col in normalized_df.columns:
                    if method == 'zscore':
                        normalized_df[f'{col}_norm'] = (
                            (normalized_df[col] - normalized_df[col].mean()) /
                            normalized_df[col].std()
                        )
                    elif method == 'minmax':
                        normalized_df[f'{col}_norm'] = (
                            (normalized_df[col] - normalized_df[col].min()) /
                            (normalized_df[col].max() - normalized_df[col].min())
                        )
                        
            return normalized_df
            
        except Exception as e:
            logger.error(f"Error normalizing data: {str(e)}")
            return df
            
    def validate_and_prepare_data(
        self,
        df: pd.DataFrame,
        remove_outliers: bool = True,
        normalize: bool = True
    ) -> Tuple[pd.DataFrame, bool, List[str]]:
        """
        Complete data validation and preparation pipeline.
        
        Args:
            df: Input DataFrame
            remove_outliers: Whether to remove outliers
            normalize: Whether to normalize the data
            
        Returns:
            Tuple of (prepared DataFrame, is_valid, validation messages)
        """
        try:
            # Validate the data
            is_valid, messages = self.validate_dataframe(df)
            if not is_valid:
                return df, is_valid, messages
                
            # Preprocess the data
            processed_df = self.preprocess_data(df)
            
            # Remove outliers if requested
            if remove_outliers:
                processed_df = self.remove_outliers(
                    processed_df,
                    ['close', 'volume', 'returns']
                )
                
            # Normalize if requested
            if normalize:
                processed_df = self.normalize_data(
                    processed_df,
                    ['close', 'volume', 'returns'],
                    method='zscore'
                )
                
            messages.append("Data preparation completed successfully")
            return processed_df, True, messages
            
        except Exception as e:
            logger.error(f"Error in data preparation pipeline: {str(e)}")
            return df, False, [f"Error in data preparation: {str(e)}"]
