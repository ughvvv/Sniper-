"""
Time-related utility functions and classes for data analysis.
"""
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Optional, Union
import pandas as pd

@dataclass
class TimeWindow:
    """
    Represents a time window for analysis.
    
    Attributes:
        start: Start of the time window
        end: End of the time window
    """
    start: datetime
    end: Optional[datetime] = None
    
    def __post_init__(self):
        """Validate and process time window after initialization."""
        # Convert string dates to datetime if necessary
        if isinstance(self.start, str):
            self.start = pd.to_datetime(self.start)
        
        if isinstance(self.end, str):
            self.end = pd.to_datetime(self.end)
        
        # If end is not provided, use current time
        if self.end is None:
            self.end = datetime.utcnow()
        
        # Ensure start is before end
        if self.start > self.end:
            raise ValueError("Start time must be before end time")

class TimeFrameGenerator:
    """Generates time frames for analysis."""
    
    @staticmethod
    def get_last_n_days(n: int) -> TimeWindow:
        """
        Get time window for the last n days.
        
        Args:
            n: Number of days
            
        Returns:
            TimeWindow object
        """
        end = datetime.utcnow()
        start = end - timedelta(days=n)
        return TimeWindow(start, end)
    
    @staticmethod
    def get_last_n_weeks(n: int) -> TimeWindow:
        """
        Get time window for the last n weeks.
        
        Args:
            n: Number of weeks
            
        Returns:
            TimeWindow object
        """
        return TimeFrameGenerator.get_last_n_days(n * 7)
    
    @staticmethod
    def get_last_n_months(n: int) -> TimeWindow:
        """
        Get time window for the last n months.
        
        Args:
            n: Number of months
            
        Returns:
            TimeWindow object
        """
        end = datetime.utcnow()
        # Approximate months as 30.44 days
        start = end - timedelta(days=int(n * 30.44))
        return TimeWindow(start, end)
    
    @staticmethod
    def get_year_to_date() -> TimeWindow:
        """
        Get time window from start of current year to now.
        
        Returns:
            TimeWindow object
        """
        end = datetime.utcnow()
        start = datetime(end.year, 1, 1)
        return TimeWindow(start, end)
    
    @staticmethod
    def get_custom_range(
        start: Union[str, datetime],
        end: Optional[Union[str, datetime]] = None
    ) -> TimeWindow:
        """
        Get custom time window.
        
        Args:
            start: Start time
            end: End time (optional)
            
        Returns:
            TimeWindow object
        """
        return TimeWindow(start, end)

def timestamp_to_unix(timestamp: Union[str, datetime]) -> int:
    """
    Convert timestamp to Unix timestamp.
    
    Args:
        timestamp: Timestamp to convert
        
    Returns:
        Unix timestamp in seconds
    """
    if isinstance(timestamp, str):
        timestamp = pd.to_datetime(timestamp)
    return int(timestamp.timestamp())

def unix_to_timestamp(unix_time: int) -> datetime:
    """
    Convert Unix timestamp to datetime.
    
    Args:
        unix_time: Unix timestamp in seconds
        
    Returns:
        datetime object
    """
    return datetime.fromtimestamp(unix_time)

def get_time_intervals(window: TimeWindow, interval: str) -> list[datetime]:
    """
    Generate list of timestamps at specified intervals within a time window.
    
    Args:
        window: TimeWindow object
        interval: Time interval (e.g., '1h', '1d', '1w')
        
    Returns:
        List of datetime objects
    """
    # Convert interval string to timedelta
    interval_map = {
        '1m': timedelta(minutes=1),
        '5m': timedelta(minutes=5),
        '15m': timedelta(minutes=15),
        '30m': timedelta(minutes=30),
        '1h': timedelta(hours=1),
        '4h': timedelta(hours=4),
        '1d': timedelta(days=1),
        '1w': timedelta(weeks=1)
    }
    
    if interval not in interval_map:
        raise ValueError(f"Invalid interval: {interval}")
    
    delta = interval_map[interval]
    timestamps = []
    current = window.start
    
    while current <= window.end:
        timestamps.append(current)
        current += delta
    
    return timestamps

def is_market_hours(timestamp: datetime) -> bool:
    """
    Check if given timestamp is during typical market hours (UTC).
    Crypto markets are 24/7, but this can be useful for volume analysis.
    
    Args:
        timestamp: Timestamp to check
        
    Returns:
        Boolean indicating if timestamp is during market hours
    """
    # Convert to UTC if not already
    if timestamp.tzinfo is None:
        timestamp = timestamp.replace(tzinfo=pd.UTC)
    
    # Define market hours (UTC)
    market_start = timestamp.replace(hour=0, minute=0, second=0, microsecond=0)
    market_end = timestamp.replace(hour=23, minute=59, second=59, microsecond=999999)
    
    return market_start <= timestamp <= market_end

def get_time_period_label(window: TimeWindow) -> str:
    """
    Get human-readable label for time period.
    
    Args:
        window: TimeWindow object
        
    Returns:
        String label describing the time period
    """
    delta = window.end - window.start
    days = delta.days
    
    if days <= 1:
        return "24 Hours"
    elif days <= 7:
        return f"{days} Days"
    elif days <= 31:
        return f"{days//7} Weeks"
    elif days <= 365:
        return f"{days//30} Months"
    else:
        return f"{days//365} Years"
