"""
Visualization utilities for the Solana Meme Analysis project.
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List, Optional, Tuple
import logging
from ..config.settings import PATTERN_RECOGNITION
import mplfinance as mpf
from datetime import datetime

logger = logging.getLogger(__name__)

class PatternVisualizer:
    """Handles visualization of price patterns and technical indicators."""
    
    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize the pattern visualizer.
        
        Args:
            config: Optional configuration dictionary to override default settings
        """
        self.config = PATTERN_RECOGNITION['visualization']
        if config:
            self.config.update(config)
            
        # Set default style
        plt.style.use(self.config['chart_style'])
        
    def plot_price_pattern(
        self,
        df: pd.DataFrame,
        patterns: List[Dict],
        save_path: Optional[str] = None
    ) -> None:
        """
        Create a comprehensive price pattern visualization.
        
        Args:
            df: DataFrame containing price and volume data
            patterns: List of identified patterns with metadata
            save_path: Optional path to save the visualization
        """
        try:
            # Create figure and grid
            fig = plt.figure(figsize=self.config['figure_size'], dpi=self.config['dpi'])
            gs = fig.add_gridspec(3, 1, height_ratios=[2, 1, 1])
            
            # Price and pattern subplot
            ax1 = fig.add_subplot(gs[0])
            self._plot_price_and_patterns(ax1, df, patterns)
            
            # Volume subplot
            ax2 = fig.add_subplot(gs[1], sharex=ax1)
            self._plot_volume_profile(ax2, df)
            
            # Technical indicators subplot
            ax3 = fig.add_subplot(gs[2], sharex=ax1)
            self._plot_technical_indicators(ax3, df)
            
            # Adjust layout and display
            plt.tight_layout()
            
            if save_path:
                plt.savefig(save_path)
            else:
                plt.show()
                
            plt.close()
            
        except Exception as e:
            logger.error(f"Error creating pattern visualization: {str(e)}")
            raise
            
    def _plot_price_and_patterns(
        self,
        ax: plt.Axes,
        df: pd.DataFrame,
        patterns: List[Dict]
    ) -> None:
        """Plot price data with identified patterns."""
        try:
            # Plot price
            ax.plot(df.index, df['close'], label='Price', color='white', linewidth=1)
            
            # Plot patterns
            for pattern in patterns:
                idx = pattern['index']
                if pattern['breakout_type'] == 'bullish':
                    color = 'green'
                    marker = '^'
                else:
                    color = 'red'
                    marker = 'v'
                    
                ax.scatter(
                    idx,
                    df['close'].iloc[idx],
                    color=color,
                    marker=marker,
                    s=100,
                    label=f"{pattern['breakout_type'].capitalize()} Pattern"
                )
                
                # Add confidence score annotation
                ax.annotate(
                    f"Conf: {pattern['confidence_score']:.2f}",
                    (idx, df['close'].iloc[idx]),
                    xytext=(10, 10),
                    textcoords='offset points',
                    color=color
                )
                
            # Plot Bollinger Bands if available
            if all(col in df.columns for col in ['bollinger_upper', 'bollinger_lower']):
                ax.fill_between(
                    df.index,
                    df['bollinger_upper'],
                    df['bollinger_lower'],
                    alpha=0.1,
                    color='white'
                )
                
            ax.set_title('Price Pattern Analysis')
            ax.set_ylabel('Price')
            ax.grid(True, alpha=0.2)
            ax.legend()
            
        except Exception as e:
            logger.error(f"Error plotting price and patterns: {str(e)}")
            raise
            
    def _plot_volume_profile(self, ax: plt.Axes, df: pd.DataFrame) -> None:
        """Plot volume profile and analysis."""
        try:
            # Plot volume bars
            ax.bar(
                df.index,
                df['volume'],
                alpha=0.5,
                color='blue',
                label='Volume'
            )
            
            # Plot volume MA if available
            if 'volume_ma' in df.columns:
                ax.plot(
                    df.index,
                    df['volume_ma'],
                    color='yellow',
                    label='Volume MA'
                )
                
            ax.set_ylabel('Volume')
            ax.grid(True, alpha=0.2)
            ax.legend()
            
        except Exception as e:
            logger.error(f"Error plotting volume profile: {str(e)}")
            raise
            
    def _plot_technical_indicators(self, ax: plt.Axes, df: pd.DataFrame) -> None:
        """Plot technical indicators."""
        try:
            # Plot RSI if available
            if 'rsi' in df.columns:
                ax.plot(df.index, df['rsi'], label='RSI', color='purple')
                ax.axhline(y=70, color='r', linestyle='--', alpha=0.5)
                ax.axhline(y=30, color='g', linestyle='--', alpha=0.5)
                
            # Plot MACD if available
            if all(col in df.columns for col in ['macd', 'macd_signal']):
                ax.plot(df.index, df['macd'], label='MACD', color='blue')
                ax.plot(df.index, df['macd_signal'], label='Signal', color='orange')
                
            ax.set_ylabel('Indicators')
            ax.grid(True, alpha=0.2)
            ax.legend()
            
        except Exception as e:
            logger.error(f"Error plotting technical indicators: {str(e)}")
            raise
            
    def create_candlestick_chart(
        self,
        df: pd.DataFrame,
        patterns: List[Dict],
        save_path: Optional[str] = None
    ) -> None:
        """
        Create a candlestick chart with patterns.
        
        Args:
            df: DataFrame containing OHLCV data
            patterns: List of identified patterns
            save_path: Optional path to save the chart
        """
        try:
            # Prepare data for mplfinance
            df_mpf = df.copy()
            if not isinstance(df_mpf.index, pd.DatetimeIndex):
                df_mpf.index = pd.to_datetime(df_mpf.index)
                
            # Create style
            mc = mpf.make_marketcolors(
                up='green',
                down='red',
                edge='inherit',
                wick='inherit',
                volume='blue'
            )
            s = mpf.make_mpf_style(
                marketcolors=mc,
                gridstyle='dotted',
                y_on_right=False
            )
            
            # Prepare pattern annotations
            annotations = []
            for pattern in patterns:
                idx = pattern['index']
                price = df['close'].iloc[idx]
                color = 'g' if pattern['breakout_type'] == 'bullish' else 'r'
                marker = '^' if pattern['breakout_type'] == 'bullish' else 'v'
                
                annotations.append(
                    dict(
                        x=idx,
                        y=price,
                        marker=marker,
                        color=color,
                        size=100
                    )
                )
                
            # Plot
            mpf.plot(
                df_mpf,
                type='candle',
                style=s,
                volume=True,
                figsize=self.config['figure_size'],
                alines=dict(alines=annotations),
                savefig=save_path if save_path else None
            )
            
        except Exception as e:
            logger.error(f"Error creating candlestick chart: {str(e)}")
            raise
            
    def plot_pattern_distribution(
        self,
        patterns: List[Dict],
        save_path: Optional[str] = None
    ) -> None:
        """
        Create a distribution plot of pattern confidence scores.
        
        Args:
            patterns: List of identified patterns
            save_path: Optional path to save the plot
        """
        try:
            confidence_scores = [p['confidence_score'] for p in patterns]
            breakout_types = [p['breakout_type'] for p in patterns]
            
            plt.figure(figsize=self.config['figure_size'], dpi=self.config['dpi'])
            
            # Create violin plot
            sns.violinplot(
                x=breakout_types,
                y=confidence_scores,
                palette=['green', 'red']
            )
            
            plt.title('Pattern Confidence Score Distribution')
            plt.xlabel('Breakout Type')
            plt.ylabel('Confidence Score')
            
            if save_path:
                plt.savefig(save_path)
            else:
                plt.show()
                
            plt.close()
            
        except Exception as e:
            logger.error(f"Error plotting pattern distribution: {str(e)}")
            raise
            
    def plot_volume_profile_analysis(
        self,
        df: pd.DataFrame,
        patterns: List[Dict],
        save_path: Optional[str] = None
    ) -> None:
        """
        Create a volume profile analysis visualization.
        
        Args:
            df: DataFrame containing price and volume data
            patterns: List of identified patterns
            save_path: Optional path to save the visualization
        """
        try:
            fig, (ax1, ax2) = plt.subplots(
                2,
                1,
                figsize=self.config['figure_size'],
                dpi=self.config['dpi'],
                height_ratios=[3, 1]
            )
            
            # Price and volume profile
            self._plot_price_and_volume_profile(ax1, df, patterns)
            
            # Volume distribution
            self._plot_volume_distribution(ax2, df)
            
            plt.tight_layout()
            
            if save_path:
                plt.savefig(save_path)
            else:
                plt.show()
                
            plt.close()
            
        except Exception as e:
            logger.error(f"Error plotting volume profile analysis: {str(e)}")
            raise
            
    def _plot_price_and_volume_profile(
        self,
        ax: plt.Axes,
        df: pd.DataFrame,
        patterns: List[Dict]
    ) -> None:
        """Plot price with volume profile overlay."""
        try:
            # Plot price
            ax.plot(df.index, df['close'], color='white', alpha=0.7)
            
            # Create volume profile
            prices = df['close'].values
            volumes = df['volume'].values
            
            # Calculate volume-weighted price levels
            price_levels = np.linspace(prices.min(), prices.max(), 50)
            volume_profile = np.zeros_like(price_levels)
            
            for i, level in enumerate(price_levels):
                mask = (prices >= level - (price_levels[1] - price_levels[0])/2) & \
                       (prices < level + (price_levels[1] - price_levels[0])/2)
                volume_profile[i] = volumes[mask].sum()
                
            # Normalize and plot volume profile
            volume_profile = volume_profile / volume_profile.max()
            ax.barh(
                price_levels,
                volume_profile,
                alpha=0.3,
                color='blue',
                height=(prices.max() - prices.min())/50
            )
            
            # Add patterns
            for pattern in patterns:
                idx = pattern['index']
                color = 'green' if pattern['breakout_type'] == 'bullish' else 'red'
                ax.scatter(
                    idx,
                    df['close'].iloc[idx],
                    color=color,
                    marker='o',
                    s=100
                )
                
            ax.set_title('Price with Volume Profile')
            ax.grid(True, alpha=0.2)
            
        except Exception as e:
            logger.error(f"Error plotting price and volume profile: {str(e)}")
            raise
            
    def _plot_volume_distribution(self, ax: plt.Axes, df: pd.DataFrame) -> None:
        """Plot volume distribution analysis."""
        try:
            # Create volume distribution
            sns.histplot(
                data=df,
                x='volume',
                bins=50,
                ax=ax,
                color='blue',
                alpha=0.5
            )
            
            ax.set_title('Volume Distribution')
            ax.grid(True, alpha=0.2)
            
        except Exception as e:
            logger.error(f"Error plotting volume distribution: {str(e)}")
            raise
