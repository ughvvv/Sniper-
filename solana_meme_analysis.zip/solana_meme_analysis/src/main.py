"""
Main entry point for Solana meme coin analysis.
"""
import asyncio
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict, List

from .collectors.market.price_collector import PriceDataCollector
from .collectors.social.social_collector import SocialDataCollector
from .analysis.price.historical_analysis import HistoricalAnalysis
from .config.settings import DATA_DIR, LOGS_DIR

logger = logging.getLogger(__name__)

class MemeAnalyzer:
    """Main class for coordinating meme coin analysis."""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize the meme analyzer.
        
        Args:
            config_path: Path to custom config file (optional)
        """
        self.config = self._load_config(config_path)
        self.data_dir = Path(DATA_DIR)
        self.data_dir.mkdir(parents=True, exist_ok=True)
    
    @staticmethod
    def _load_config(config_path: Optional[str] = None) -> Dict:
        """Load analysis configuration."""
        default_config_path = Path(__file__).parent.parent / "config" / "analysis_config.json"
        config_file = Path(config_path) if config_path else default_config_path
        
        try:
            with open(config_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading config: {str(e)}")
            raise
    
    async def collect_current_data(
        self,
        days: Optional[int] = None
    ) -> List[Dict]:
        """
        Collect current market and social data for top meme coins.
        
        Args:
            days: Number of days of historical data to collect
            
        Returns:
            List of dictionaries containing token data
        """
        days = days or self.config['data_collection']['default_time_period_days']
        
        collector_config = {
            'max_requests_per_minute': self.config['rate_limits']['birdeye_requests_per_minute'],
            'twitter_requests_per_15min': self.config['rate_limits']['twitter_requests_per_15min']
        }
        
        try:
            async with PriceDataCollector(collector_config) as price_collector, \
                       SocialDataCollector(collector_config) as social_collector:
                
                # Get top performing tokens
                tokens = await price_collector.get_top_performing_tokens(
                    limit=self.config['data_collection']['max_tokens'],
                    days=days,
                    min_liquidity=self.config['data_collection']['min_liquidity_usd']
                )
                
                if not tokens:
                    logger.warning("No tokens found matching criteria")
                    return []
                
                # Collect social data
                token_addresses = [token['address'] for token in tokens]
                social_data = await social_collector.batch_collect_social_data(token_addresses)
                
                # Combine data
                combined_data = []
                for token, social in zip(tokens, social_data):
                    if 'error' not in social:
                        combined_data.append({**token, **social})
                
                # Save data
                timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
                output_file = self.data_dir / f'top_memecoins_{timestamp}.json'
                
                with open(output_file, 'w') as f:
                    json.dump(combined_data, f, indent=2)
                
                return combined_data
                
        except Exception as e:
            logger.error(f"Error collecting data: {str(e)}")
            return []
    
    async def analyze_trends(
        self,
        days: Optional[int] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> Dict:
        """
        Analyze historical trends and patterns.
        
        Args:
            days: Number of days to analyze
            start_date: Start date for analysis
            end_date: End date for analysis
            
        Returns:
            Dictionary containing analysis results
        """
        try:
            analyzer = HistoricalAnalysis(self.data_dir)
            
            if days:
                end_date = end_date or datetime.utcnow()
                start_date = end_date - timedelta(days=days)
            
            # Load and analyze historical data
            data = analyzer.load_historical_data(start_date, end_date)
            
            if data.empty:
                logger.warning("No historical data found for analysis")
                return {}
            
            # Analyze trends
            market_stats = analyzer.analyze_performance_trends(
                data,
                min_snapshots=self.config['reporting']['minimum_data_points']
            )
            
            # Identify patterns
            launch_patterns = analyzer.identify_launch_patterns(data)
            
            # Combine results
            results = {
                'market_stats': market_stats,
                'launch_patterns': launch_patterns,
                'analysis_period': {
                    'start': start_date.isoformat() if start_date else None,
                    'end': end_date.isoformat() if end_date else None
                }
            }
            
            # Save results
            timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
            output_file = self.data_dir / f'analysis_results_{timestamp}.json'
            
            with open(output_file, 'w') as f:
                json.dump(results, f, indent=2)
            
            return results
            
        except Exception as e:
            logger.error(f"Error analyzing trends: {str(e)}")
            return {}
    
    async def run_full_analysis(self, days: int = 30) -> Dict:
        """
        Run a complete analysis cycle: collect new data and analyze trends.
        
        Args:
            days: Number of days to analyze
            
        Returns:
            Dictionary containing analysis results
        """
        try:
            # Collect current data
            logger.info("Collecting current market data...")
            await self.collect_current_data(days)
            
            # Analyze trends
            logger.info("Analyzing historical trends...")
            results = await self.analyze_trends(days)
            
            return results
            
        except Exception as e:
            logger.error(f"Error running full analysis: {str(e)}")
            return {}

async def main():
    """Main function to demonstrate usage."""
    try:
        analyzer = MemeAnalyzer()
        results = await analyzer.run_full_analysis()
        
        if results:
            print("\nAnalysis Results:")
            print(f"Total Tokens Analyzed: {results['market_stats']['total_tokens_analyzed']}")
            print(f"Positive Trends: {results['market_stats']['positive_trend_count']}")
            print(f"Negative Trends: {results['market_stats']['negative_trend_count']}")
            
            print("\nTop Performers:")
            for token in results['market_stats']['top_performers'][:5]:
                print(f"\n{token['symbol']} ({token['name']})")
                print(f"Price Trend: {token['price_trend']:.2f}")
                print(f"Social Score: {token['social_presence_score']:.2f}")
        
    except Exception as e:
        logger.error(f"Error in main: {str(e)}")

if __name__ == "__main__":
    asyncio.run(main())
