"""
Order Book Data Collection Module for Solana Meme Coins.
"""
import logging
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import aiohttp
import asyncio
import pandas as pd
from ...utils.rate_limiter import RateLimiter
from ...config.settings import ORDER_BOOK_API_KEY, ORDER_BOOK_API_URL

logger = logging.getLogger(__name__)

class OrderBookCollector:
    """Collects historical order book data from Solana DEXes."""

    def __init__(self, config: Dict):
        """
        Initialize the order book data collector.

        Args:
            config: Configuration dictionary containing API endpoints and settings
        """
        self.config = config
        self.session = None
        self.rate_limiter = RateLimiter(
            max_requests=config.get('max_requests_per_minute', 60),
            time_window=60
        )
        self.headers = {
            'Authorization': f"Bearer {ORDER_BOOK_API_KEY}",
            'Accept': 'application/json'
        }

    async def __aenter__(self):
        """Set up async context manager."""
        self.session = aiohttp.ClientSession(headers=self.headers)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Clean up async context manager."""
        if self.session:
            await self.session.close()

    async def collect_order_book_data(
        self,
        token_address: str,
        start_time: datetime,
        end_time: Optional[datetime] = None,
        depth: int = 10,
        interval: str = '1h'
    ) -> pd.DataFrame:
        """
        Collect historical order book depth data for a token.

        Args:
            token_address: The token's contract address
            start_time: Start time for data collection
            end_time: End time for data collection (defaults to current time)
            depth: Number of levels in the order book to retrieve
            interval: Time interval for the data points ('1m', '5m', '1h')

        Returns:
            DataFrame containing historical order book data
        """
        try:
            end_time = end_time or datetime.utcnow()

            async with self.rate_limiter:
                raw_data = await self._fetch_order_book_data(
                    token_address,
                    start_time,
                    end_time,
                    depth,
                    interval
                )

                df = pd.DataFrame(self._process_raw_data(raw_data))

                return df

        except Exception as e:
            logger.error(f"Error collecting order book data: {str(e)}")
            return pd.DataFrame()

    async def _fetch_order_book_data(
        self,
        token_address: str,
        start_time: datetime,
        end_time: datetime,
        depth: int,
        interval: str
    ) -> List[Dict]:
        """Fetch raw order book data from the API."""
        endpoint = f"{ORDER_BOOK_API_URL}/orderbook/historical"
        params = {
            'address': token_address,
            'start_time': int(start_time.timestamp()),
            'end_time': int(end_time.timestamp()),
            'depth': depth,
            'interval': interval
        }

        async with self.session.get(endpoint, params=params) as response:
            if response.status != 200:
                raise Exception(f"API request failed with status {response.status}")

            data = await response.json()
            return data.get('data', [])

    @staticmethod
    def _process_raw_data(raw_data: List[Dict]) -> List[Dict]:
        """
        Process raw order book data into standardized format.

        Args:
            raw_data: Raw data from the API

        Returns:
            List of processed data points
        """
        processed_data = []
        for item in raw_data:
            bids = item.get('bids', [])
            asks = item.get('asks', [])
            timestamp = datetime.fromtimestamp(item.get('timestamp', 0))

            for level in range(len(bids)):
                processed_data.append({
                    'timestamp': timestamp,
                    'side': 'bid',
                    'level': level + 1,
                    'price': float(bids[level]['price']),
                    'size': float(bids[level]['size'])
                })

            for level in range(len(asks)):
                processed_data.append({
                    'timestamp': timestamp,
                    'side': 'ask',
                    'level': level + 1,
                    'price': float(asks[level]['price']),
                    'size': float(asks[level]['size'])
                })

        return processed_data
