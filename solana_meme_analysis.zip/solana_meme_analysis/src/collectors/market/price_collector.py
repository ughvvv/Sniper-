"""
Market price data collection module for Solana meme coins.
"""
import logging
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import aiohttp
import pandas as pd
import asyncio
from ...utils.rate_limiter import RateLimiter
from ...config.settings import BIRDEYE_API_KEY, BIRDEYE_API_URL
from functools import lru_cache

logger = logging.getLogger(__name__)

class TokenMetrics:
    """Data class for token metrics."""
    
    def __init__(self, data: Dict):
        """Initialize from API response data."""
        self.address = data.get('address')
        self.symbol = data.get('symbol')
        self.name = data.get('name')
        self.decimals = data.get('decimals')
        
        # Basic info
        self.price = float(data.get('price', 0))
        self.liquidity = float(data.get('liquidity', 0))
        self.volume_24h = float(data.get('v24h', 0))
        self.market_cap = float(data.get('mc', 0))
        
        # Social and metadata
        extensions = data.get('extensions', {})
        self.website = extensions.get('website')
        self.telegram = extensions.get('telegram')
        self.twitter = extensions.get('twitter')
        self.discord = extensions.get('discord')
        self.medium = extensions.get('medium')
        self.description = extensions.get('description')
        self.coingecko_id = extensions.get('coingeckoId')
        self.logo_uri = data.get('logoURI')
        
        # Market metrics
        self.holder_count = int(data.get('holder', 0))
        self.number_markets = int(data.get('numberMarkets', 0))
        self.supply = float(data.get('supply', 0))
        self.circulating_supply = float(data.get('circulatingSupply', 0))
        
        # Trading metrics
        self.unique_wallets_24h = int(data.get('uniqueWallet24h', 0))
        self.unique_wallets_change_24h = float(data.get('uniqueWallet24hChangePercent', 0))
        self.trades_24h = int(data.get('trade24h', 0))
        self.trades_change_24h = float(data.get('trade24hChangePercent', 0))
        
        # Volume breakdowns
        self.buy_volume_24h = float(data.get('vBuy24h', 0))
        self.sell_volume_24h = float(data.get('vSell24h', 0))
        self.buy_count_24h = int(data.get('buy24h', 0))
        self.sell_count_24h = int(data.get('sell24h', 0))
        
        # Price changes
        self.price_change_1h = float(data.get('priceChange1hPercent', 0))
        self.price_change_24h = float(data.get('priceChange24hPercent', 0))
        
        # Last trade
        self.last_trade_time = datetime.fromtimestamp(int(data.get('lastTradeUnixTime', 0)))

class PriceDataCollector:
    """Collects historical price data from Solana DEXes using Birdeye API."""
    
    def __init__(self, config: Dict):
        """
        Initialize the price data collector.
        
        Args:
            config: Configuration dictionary containing API endpoints and settings
        """
        self.config = config
        self.session = None
        self.rate_limiter = RateLimiter(
            max_requests=config.get('max_requests_per_minute', 60),
            time_window=60
        )
        self.headers = {
            'X-API-KEY': BIRDEYE_API_KEY,
            'Accept': 'application/json'
        }
        
        # Cache settings
        self.cache_duration = timedelta(minutes=5)  # Cache data for 5 minutes
        self.last_cache_time = {}
        self.price_cache = {}
    
    async def __aenter__(self):
        """Set up async context manager."""
        self.session = aiohttp.ClientSession(headers=self.headers)
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Clean up async context manager."""
        if self.session:
            await self.session.close()
    
    async def get_top_performing_tokens(
        self,
        limit: int = 1000,
        min_liquidity: float = 10000  # Minimum liquidity in USD
    ) -> List[Dict]:
        """
        Get top performing tokens based on price performance.
        
        Args:
            limit: Number of top tokens to return
            min_liquidity: Minimum liquidity threshold in USD
            
        Returns:
            List of dictionaries containing token data
        """
        cache_key = f"top_tokens_{limit}_{min_liquidity}"
        if self._is_cache_valid(cache_key):
            return self.price_cache[cache_key]
        
        try:
            tokens = []
            offset = 0
            batch_size = 100  # Birdeye API pagination size
            
            while len(tokens) < limit:
                async with self.rate_limiter:
                    endpoint = f"{BIRDEYE_API_URL}/defi/tokens"
                    params = {
                        'offset': offset,
                        'limit': batch_size,
                        'sort_by': 'v24h',  # Sort by 24h volume
                        'sort_type': 'desc'
                    }
                    
                    async with self.session.get(endpoint, params=params) as response:
                        if response.status != 200:
                            raise Exception(f"API request failed with status {response.status}")
                        
                        data = await response.json()
                        batch_tokens = data.get('data', {}).get('tokens', [])
                        
                        if not batch_tokens:
                            break
                        
                        # Process tokens
                        tasks = []
                        for token_data in batch_tokens:
                            metrics = TokenMetrics(token_data)
                            
                            if metrics.liquidity >= min_liquidity:
                                # Create task for fetching performance data
                                task = self._get_token_performance(metrics)
                                tasks.append(task)
                        
                        # Execute tasks concurrently
                        token_results = await asyncio.gather(*tasks)
                        tokens.extend([t for t in token_results if t])
                
                offset += batch_size
                if offset >= 5000:  # Safety limit
                    break
            
            # Sort by performance over the specified time period
            tokens.sort(key=lambda x: x.get('volume_24h', 0), reverse=True)
            result = tokens[:limit]
            
            # Update cache
            self.price_cache[cache_key] = result
            self.last_cache_time[cache_key] = datetime.now()
            
            return result
            
        except Exception as e:
            logger.error(f"Error fetching top performing tokens: {str(e)}")
            return []
    
    async def _get_token_performance(self, metrics: TokenMetrics) -> Optional[Dict]:
        """
        Calculate token performance metrics with short-term data.
        
        Args:
            metrics: TokenMetrics instance
            
        Returns:
            Dictionary containing performance metrics
        """
        try:
            # Get 1-minute and 1-hour interval data concurrently
            minute_data, hour_data = await asyncio.gather(
                self.collect_historical_prices(
                    metrics.address,
                    datetime.utcnow() - timedelta(hours=1),
                    interval='1m'
                ),
                self.collect_historical_prices(
                    metrics.address,
                    datetime.utcnow() - timedelta(hours=24),
                    interval='1h'
                )
            )
            
            if minute_data.empty and hour_data.empty:
                return None
            
            # Calculate short-term metrics from 1-minute data
            short_term_metrics = self._calculate_interval_metrics(minute_data) if not minute_data.empty else {}
            
            # Calculate medium-term metrics from 1-hour data
            medium_term_metrics = self._calculate_interval_metrics(hour_data) if not hour_data.empty else {}
            
            return {
                # Basic info
                'address': metrics.address,
                'symbol': metrics.symbol,
                'name': metrics.name,
                'decimals': metrics.decimals,
                'logo_uri': metrics.logo_uri,
                
                # Market metrics
                'price': metrics.price,
                'liquidity': metrics.liquidity,
                'volume_24h': metrics.volume_24h,
                'market_cap': metrics.market_cap,
                'holder_count': metrics.holder_count,
                'number_markets': metrics.number_markets,
                'supply': metrics.supply,
                'circulating_supply': metrics.circulating_supply,
                
                # Trading metrics
                'unique_wallets_24h': metrics.unique_wallets_24h,
                'unique_wallets_change_24h': metrics.unique_wallets_change_24h,
                'trades_24h': metrics.trades_24h,
                'trades_change_24h': metrics.trades_change_24h,
                'buy_volume_24h': metrics.buy_volume_24h,
                'sell_volume_24h': metrics.sell_volume_24h,
                'buy_count_24h': metrics.buy_count_24h,
                'sell_count_24h': metrics.sell_count_24h,
                
                # Social and metadata
                'website': metrics.website,
                'telegram': metrics.telegram,
                'twitter': metrics.twitter,
                'discord': metrics.discord,
                'medium': metrics.medium,
                'description': metrics.description,
                'coingecko_id': metrics.coingecko_id,
                
                # Short-term metrics (1-minute interval)
                **{f'1m_{k}': v for k, v in short_term_metrics.items()},
                
                # Medium-term metrics (1-hour interval)
                **{f'1h_{k}': v for k, v in medium_term_metrics.items()},
                
                # Last update
                'last_trade_time': metrics.last_trade_time.isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error calculating token performance: {str(e)}")
            return None
    
    def _calculate_interval_metrics(self, df: pd.DataFrame) -> Dict:
        """Calculate performance metrics for a specific interval."""
        try:
            if df.empty:
                return {}
            
            initial_price = df['close'].iloc[0]
            final_price = df['close'].iloc[-1]
            
            price_change = final_price - initial_price
            price_change_percent = (price_change / initial_price) * 100 if initial_price > 0 else 0
            
            # Calculate additional metrics
            volatility = df['close'].pct_change().std() * 100  # Volatility
            max_drawdown = self._calculate_max_drawdown(df['close'])
            
            return {
                'price_change': float(price_change),
                'price_change_percent': float(price_change_percent),
                'high': float(df['high'].max()),
                'low': float(df['low'].min()),
                'avg_volume': float(df['volume'].mean()),
                'volatility': float(volatility),
                'max_drawdown': float(max_drawdown)
            }
            
        except Exception as e:
            logger.error(f"Error calculating interval metrics: {str(e)}")
            return {}
    
    @staticmethod
    def _calculate_max_drawdown(prices: pd.Series) -> float:
        """Calculate the maximum drawdown percentage."""
        rolling_max = prices.expanding().max()
        drawdowns = (prices - rolling_max) / rolling_max * 100
        return abs(float(drawdowns.min()))
    
    async def collect_historical_prices(
        self,
        token_address: str,
        start_time: datetime,
        end_time: Optional[datetime] = None,
        interval: str = '1h'
    ) -> pd.DataFrame:
        """
        Collect historical price data for a token.
        
        Args:
            token_address: The token's contract address
            start_time: Start time for data collection
            end_time: End time for data collection (defaults to current time)
            interval: Time interval for the data points ('1m', '5m', '1h', '1d')
            
        Returns:
            DataFrame containing historical price data
        """
        cache_key = f"{token_address}_{interval}_{start_time.timestamp()}"
        if self._is_cache_valid(cache_key):
            return self.price_cache[cache_key]
        
        try:
            end_time = end_time or datetime.utcnow()
            
            async with self.rate_limiter:
                raw_data = await self._fetch_price_data(
                    token_address,
                    start_time,
                    end_time,
                    interval
                )
                
                df = pd.DataFrame(self._process_raw_data(raw_data))
                
                # Update cache
                self.price_cache[cache_key] = df
                self.last_cache_time[cache_key] = datetime.now()
                
                return df
            
        except Exception as e:
            logger.error(f"Error collecting historical prices: {str(e)}")
            return pd.DataFrame()
    
    async def _fetch_price_data(
        self,
        token_address: str,
        start_time: datetime,
        end_time: datetime,
        interval: str
    ) -> List[Dict]:
        """Fetch raw price data from the Birdeye API."""
        endpoint = f"{BIRDEYE_API_URL}/defi/token_overview"
        params = {
            'address': token_address,
            'interval': interval,
            'start_time': int(start_time.timestamp()),
            'end_time': int(end_time.timestamp())
        }
        
        async with self.session.get(endpoint, params=params) as response:
            if response.status != 200:
                raise Exception(f"API request failed with status {response.status}")
            
            data = await response.json()
            return data.get('data', {}).get('price_history', [])
    
    @staticmethod
    def _process_raw_data(raw_data: List[Dict]) -> List[Dict]:
        """
        Process raw price data into standardized format.
        
        Args:
            raw_data: Raw data from the API
            
        Returns:
            List of processed data points
        """
        processed_data = []
        for item in raw_data:
            processed_data.append({
                'timestamp': datetime.fromtimestamp(item.get('unixTime', 0)),
                'open': float(item.get('value', 0)),
                'high': float(item.get('high', 0)),
                'low': float(item.get('low', 0)),
                'close': float(item.get('value', 0)),
                'volume': float(item.get('volume', 0))
            })
        return processed_data
    
    def _is_cache_valid(self, cache_key: str) -> bool:
        """Check if cached data is still valid."""
        if cache_key not in self.last_cache_time:
            return False
        
        age = datetime.now() - self.last_cache_time[cache_key]
        return age < self.cache_duration
