"""
OpenAI API interface for model distillation and analysis.
"""
import logging
import json
from typing import Dict, List, Any
import openai
from ..config.settings import OPENAI_API_KEY, MODEL_SETTINGS

logger = logging.getLogger(__name__)
openai.api_key = OPENAI_API_KEY

class OpenAIAnalyzer:
    """Interface for OpenAI API analysis and model distillation."""
    
    def __init__(self):
        """Initialize the OpenAI analyzer with default settings."""
        self.model_settings = MODEL_SETTINGS["openai"]
        
    async def analyze_patterns(self, historical_data: List[Dict]) -> Dict:
        """
        Analyze historical patterns using OpenAI.
        
        Args:
            historical_data: List of historical data points
            
        Returns:
            Dict containing analysis results
        """
        try:
            # Prepare data for API consumption
            formatted_data = self._format_data_for_api(historical_data)
            
            response = await openai.ChatCompletion.acreate(
                model=self.model_settings["model"],
                messages=[
                    {"role": "system", "content": "You are a cryptocurrency market analyst specializing in meme coins on Solana."},
                    {"role": "user", "content": f"Analyze these historical patterns:\n{formatted_data}"}
                ],
                temperature=self.model_settings["temperature"],
                max_tokens=self.model_settings["max_tokens"]
            )
            
            return self._parse_analysis_response(response)
            
        except Exception as e:
            logger.error(f"Error in pattern analysis: {str(e)}")
            return {"error": str(e)}
    
    async def generate_trading_strategy(self, analysis_results: Dict) -> Dict:
        """
        Generate trading strategy based on analysis results.
        
        Args:
            analysis_results: Dictionary containing analysis results
            
        Returns:
            Dict containing trading strategy
        """
        try:
            formatted_analysis = json.dumps(analysis_results, indent=2)
            
            response = await openai.ChatCompletion.acreate(
                model=self.model_settings["model"],
                messages=[
                    {"role": "system", "content": "You are a cryptocurrency trading strategy expert."},
                    {"role": "user", "content": f"Generate a trading strategy based on this analysis:\n{formatted_analysis}"}
                ],
                temperature=self.model_settings["temperature"],
                max_tokens=self.model_settings["max_tokens"]
            )
            
            return self._parse_strategy_response(response)
            
        except Exception as e:
            logger.error(f"Error generating trading strategy: {str(e)}")
            return {"error": str(e)}
    
    async def distill_model(self, training_data: List[Dict]) -> Dict:
        """
        Distill insights from historical data into a predictive model.
        
        Args:
            training_data: List of training data points
            
        Returns:
            Dict containing model parameters and insights
        """
        try:
            formatted_training = self._format_data_for_api(training_data)
            
            response = await openai.ChatCompletion.acreate(
                model=self.model_settings["model"],
                messages=[
                    {"role": "system", "content": "You are an AI model architect specializing in cryptocurrency prediction models."},
                    {"role": "user", "content": f"Distill this training data into a predictive model:\n{formatted_training}"}
                ],
                temperature=self.model_settings["temperature"],
                max_tokens=self.model_settings["max_tokens"]
            )
            
            return self._parse_model_response(response)
            
        except Exception as e:
            logger.error(f"Error in model distillation: {str(e)}")
            return {"error": str(e)}
    
    @staticmethod
    def _format_data_for_api(data: List[Dict]) -> str:
        """Format data for API consumption."""
        return json.dumps(data, indent=2)
    
    @staticmethod
    def _parse_analysis_response(response: Any) -> Dict:
        """Parse and structure the analysis response."""
        try:
            content = response.choices[0].message.content
            return {
                "analysis": content,
                "timestamp": response.created,
                "model_used": response.model
            }
        except Exception as e:
            logger.error(f"Error parsing analysis response: {str(e)}")
            return {"error": str(e)}
    
    @staticmethod
    def _parse_strategy_response(response: Any) -> Dict:
        """Parse and structure the strategy response."""
        try:
            content = response.choices[0].message.content
            return {
                "strategy": content,
                "timestamp": response.created,
                "model_used": response.model
            }
        except Exception as e:
            logger.error(f"Error parsing strategy response: {str(e)}")
            return {"error": str(e)}
    
    @staticmethod
    def _parse_model_response(response: Any) -> Dict:
        """Parse and structure the model response."""
        try:
            content = response.choices[0].message.content
            return {
                "model_architecture": content,
                "timestamp": response.created,
                "model_used": response.model
            }
        except Exception as e:
            logger.error(f"Error parsing model response: {str(e)}")
            return {"error": str(e)}
