"""
Configuration settings for the Solana Meme Analysis project.
"""
import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Base paths
BASE_DIR = Path(__file__).resolve().parent.parent.parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"
LOGS_DIR = BASE_DIR / "logs"
CACHE_DIR = BASE_DIR / "cache"
VISUALIZATION_DIR = BASE_DIR / "visualizations"

# Create necessary directories
for directory in [DATA_DIR, MODELS_DIR, LOGS_DIR, CACHE_DIR, VISUALIZATION_DIR]:
    directory.mkdir(parents=True, exist_ok=True)

# API Keys and endpoints
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
SOLANA_RPC_URL = os.getenv("SOLANA_RPC_URL", "https://api.mainnet-beta.solana.com")
BIRDEYE_API_KEY = os.getenv("BIRDEYE_API_KEY")
BIRDEYE_API_URL = "https://public-api.birdeye.so/v1"
ORDER_BOOK_API_KEY = os.getenv("ORDER_BOOK_API_KEY")
ORDER_BOOK_API_URL = os.getenv("ORDER_BOOK_API_URL", "https://public-api.birdeye.so/v1")

# Data collection settings
HISTORICAL_DATA_DAYS = 365  # Default to 1 year of historical data
SOCIAL_MEDIA_PLATFORMS = ["twitter", "reddit", "discord"]
MAX_TOKENS_PER_REQUEST = 4000  # For OpenAI API requests

# Analysis settings
TECHNICAL_INDICATORS = [
    "SMA",
    "EMA",
    "RSI",
    "MACD",
    "BOLLINGER"
]

# Pattern Recognition Settings
PATTERN_RECOGNITION = {
    "breakout": {
        "min_data_points": 50,
        "confidence_threshold": 0.8,
        "volume_threshold_multiplier": 2.0,
        "price_volatility_window": 20,
        "support_resistance_bins": 100,
        "breakout_validation_window": 10,
        "momentum_thresholds": {
            "rsi_overbought": 70,
            "rsi_oversold": 30,
            "adx_trend_strength": 25
        }
    },
    "volume_profile": {
        "price_levels": 100,
        "min_volume_increase": 1.5,
        "analysis_window": 50
    },
    "order_book": {
        "depth_levels": 10,  # Number of price levels to analyze
        "min_liquidity_threshold": 1000,  # Minimum liquidity in USD
        "update_interval": "1m",  # Order book update interval
        "spread_analysis": {
            "max_spread_threshold": 5.0,  # Maximum acceptable spread percentage
            "min_depth_threshold": 1000,  # Minimum depth in USD
            "significant_level_threshold": 0.1  # Threshold for significant price levels
        },
        "liquidity_analysis": {
            "imbalance_threshold": 0.2,  # Maximum acceptable bid/ask imbalance
            "depth_decay_factor": 0.9,  # Weight factor for deeper levels
            "min_level_size": 100  # Minimum size for a valid level in USD
        },
        "stability_metrics": {
            "spread_volatility_threshold": 0.5,
            "depth_stability_threshold": 0.7,
            "price_impact_threshold": 0.02  # Maximum acceptable price impact
        }
    },
    "machine_learning": {
        "isolation_forest": {
            "contamination": 0.1,
            "random_state": 42
        },
        "clustering": {
            "n_clusters": 5,
            "random_state": 42
        }
    },
    "visualization": {
        "chart_style": "dark_background",
        "figure_size": (12, 8),
        "dpi": 100
    }
}

# Model settings
MODEL_SETTINGS = {
    "openai": {
        "model": "gpt-4",
        "temperature": 0.7,
        "max_tokens": 2000
    },
    "local": {
        "batch_size": 32,
        "epochs": 100,
        "learning_rate": 0.001
    },
    "lstm": {
        "sequence_length": 50,
        "hidden_layers": [64, 32],
        "dropout_rate": 0.2
    }
}

# Performance Optimization
PERFORMANCE = {
    "cache_timeout": 3600,  # 1 hour in seconds
    "max_workers": 4,  # For parallel processing
    "chunk_size": 1000,  # For data processing
    "use_multiprocessing": True
}

# Logging configuration
LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "standard": {
            "format": "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
        },
        "detailed": {
            "format": "%(asctime)s [%(levelname)s] %(name)s:%(lineno)d: %(message)s"
        }
    },
    "handlers": {
        "default": {
            "level": "INFO",
            "formatter": "standard",
            "class": "logging.StreamHandler",
        },
        "file": {
            "level": "INFO",
            "formatter": "detailed",
            "class": "logging.FileHandler",
            "filename": LOGS_DIR / "app.log",
            "mode": "a",
        },
        "error_file": {
            "level": "ERROR",
            "formatter": "detailed",
            "class": "logging.FileHandler",
            "filename": LOGS_DIR / "error.log",
            "mode": "a",
        }
    },
    "loggers": {
        "": {
            "handlers": ["default", "file", "error_file"],
            "level": "INFO",
            "propagate": True
        },
    },
}

# Error Handling
MAX_RETRIES = 3
RETRY_DELAY = 1  # seconds
ERROR_NOTIFICATION_EMAIL = os.getenv("ERROR_NOTIFICATION_EMAIL")

# Data Validation
REQUIRED_COLUMNS = ["timestamp", "open", "high", "low", "close", "volume"]
VALIDATION_RULES = {
    "min_price": 0.0,
    "min_volume": 0.0,
    "max_missing_values": 0.1  # 10% threshold
}
