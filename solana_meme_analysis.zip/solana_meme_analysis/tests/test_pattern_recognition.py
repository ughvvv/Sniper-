"""
Unit tests for the pattern recognition system.
"""
import unittest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from ..src.analysis.price.pattern_recognition import PatternRecognition
from ..src.analysis.ml.pattern_ml import PatternML
from ..src.utils.data_validation import DataValidator
import tempfile
import os

class TestPatternRecognition(unittest.TestCase):
    """Test cases for pattern recognition system."""
    
    @classmethod
    def setUpClass(cls):
        """Set up test fixtures."""
        # Create sample data
        dates = pd.date_range(
            start='2023-01-01',
            end='2023-12-31',
            freq='H'
        )
        
        cls.sample_data = pd.DataFrame({
            'timestamp': dates,
            'open': np.random.normal(100, 10, len(dates)),
            'high': np.random.normal(105, 10, len(dates)),
            'low': np.random.normal(95, 10, len(dates)),
            'close': np.random.normal(100, 10, len(dates)),
            'volume': np.random.normal(1000000, 100000, len(dates))
        })
        
        # Ensure high is always highest and low is always lowest
        cls.sample_data['high'] = cls.sample_data[['open', 'high', 'close']].max(axis=1)
        cls.sample_data['low'] = cls.sample_data[['open', 'low', 'close']].min(axis=1)
        
        # Create breakout pattern
        breakout_idx = 1000
        cls.sample_data.iloc[breakout_idx:breakout_idx+10, :] = \
            cls.sample_data.iloc[breakout_idx:breakout_idx+10, :] * 1.5
            
        # Initialize components
        cls.pattern_recognition = PatternRecognition()
        cls.ml_analyzer = PatternML()
        cls.data_validator = DataValidator()
        
    def setUp(self):
        """Set up test cases."""
        self.test_dir = tempfile.mkdtemp()
        
    def tearDown(self):
        """Clean up after tests."""
        # Remove temporary files
        for file in os.listdir(self.test_dir):
            os.remove(os.path.join(self.test_dir, file))
        os.rmdir(self.test_dir)
        
    def test_data_validation(self):
        """Test data validation functionality."""
        # Test with valid data
        is_valid, messages = self.data_validator.validate_dataframe(self.sample_data)
        self.assertTrue(is_valid)
        
        # Test with missing columns
        invalid_data = self.sample_data.drop(['volume'], axis=1)
        is_valid, messages = self.data_validator.validate_dataframe(invalid_data)
        self.assertFalse(is_valid)
        
        # Test with negative values
        invalid_data = self.sample_data.copy()
        invalid_data.loc[0, 'close'] = -100
        is_valid, messages = self.data_validator.validate_dataframe(invalid_data)
        self.assertFalse(is_valid)
        
    def test_technical_indicators(self):
        """Test technical indicator calculations."""
        df_processed = self.pattern_recognition._calculate_technical_indicators(
            self.sample_data
        )
        
        # Check if indicators were calculated
        self.assertIn('rsi', df_processed.columns)
        self.assertIn('macd', df_processed.columns)
        self.assertIn('bollinger_upper', df_processed.columns)
        
        # Verify indicator values
        self.assertTrue(df_processed['rsi'].between(0, 100).all())
        self.assertTrue(np.isfinite(df_processed['macd']).all())
        
    def test_breakout_detection(self):
        """Test breakout pattern detection."""
        # Process data
        df_processed = self.pattern_recognition._calculate_technical_indicators(
            self.sample_data
        )
        
        # Detect breakouts
        patterns, viz_paths = self.pattern_recognition.analyze_breakout_patterns(
            df_processed,
            save_visualizations=True,
            output_dir=self.test_dir
        )
        
        # Verify patterns were detected
        self.assertTrue(len(patterns) > 0)
        
        # Verify visualization files were created
        self.assertTrue(len(viz_paths) > 0)
        for path in viz_paths.values():
            self.assertTrue(os.path.exists(path))
            
    def test_ml_analysis(self):
        """Test machine learning analysis components."""
        # Prepare features
        X, y = self.ml_analyzer.prepare_features(self.sample_data)
        
        # Test feature preparation
        self.assertIsInstance(X, np.ndarray)
        self.assertIsInstance(y, np.ndarray)
        self.assertTrue(len(X) > 0)
        self.assertTrue(len(y) > 0)
        
        # Test anomaly detection
        self.ml_analyzer.train_anomaly_detector(self.sample_data)
        anomalies = self.ml_analyzer.detect_anomalies(self.sample_data)
        self.assertTrue(len(anomalies) > 0)
        
        # Test pattern classification
        self.ml_analyzer.train_pattern_classifier(self.sample_data, y)
        predictions = self.ml_analyzer.predict_patterns(self.sample_data)
        self.assertTrue(len(predictions) > 0)
        
    def test_pattern_validation(self):
        """Test pattern validation logic."""
        # Create test patterns
        test_patterns = [{
            'index': 1000,
            'timestamp': self.sample_data.index[1000],
            'price': self.sample_data['close'].iloc[1000],
            'volume': self.sample_data['volume'].iloc[1000],
            'breakout_type': 'bullish'
        }]
        
        # Validate patterns
        validated_patterns = self.pattern_recognition._validate_patterns(
            self.sample_data,
            test_patterns
        )
        
        # Verify validation results
        self.assertIsInstance(validated_patterns, list)
        if validated_patterns:
            self.assertIn('ml_confidence', validated_patterns[0])
            
    def test_visualization_generation(self):
        """Test visualization generation."""
        # Create test patterns
        test_patterns = [{
            'index': 1000,
            'timestamp': self.sample_data.index[1000],
            'price': self.sample_data['close'].iloc[1000],
            'volume': self.sample_data['volume'].iloc[1000],
            'breakout_type': 'bullish',
            'confidence_score': 0.9
        }]
        
        # Generate visualizations
        viz_paths = self.pattern_recognition._generate_visualizations(
            self.sample_data,
            test_patterns,
            self.test_dir
        )
        
        # Verify visualization files
        self.assertTrue(len(viz_paths) > 0)
        for path in viz_paths.values():
            self.assertTrue(os.path.exists(path))
            
    def test_end_to_end_analysis(self):
        """Test complete analysis pipeline."""
        # Run complete analysis
        patterns, viz_paths = self.pattern_recognition.analyze_breakout_patterns(
            self.sample_data,
            save_visualizations=True,
            output_dir=self.test_dir
        )
        
        # Verify results
        self.assertIsInstance(patterns, list)
        self.assertIsInstance(viz_paths, dict)
        
        if patterns:
            pattern = patterns[0]
            required_keys = {
                'index', 'timestamp', 'price', 'volume',
                'breakout_type', 'confidence_score'
            }
            self.assertTrue(all(key in pattern for key in required_keys))
            
        if viz_paths:
            self.assertTrue(all(os.path.exists(path) for path in viz_paths.values()))
            
    def test_error_handling(self):
        """Test error handling in pattern recognition."""
        # Test with invalid data
        invalid_data = pd.DataFrame({'invalid': [1, 2, 3]})
        patterns, viz_paths = self.pattern_recognition.analyze_breakout_patterns(
            invalid_data,
            save_visualizations=True,
            output_dir=self.test_dir
        )
        
        # Verify error handling
        self.assertEqual(len(patterns), 0)
        self.assertEqual(len(viz_paths), 0)
        
if __name__ == '__main__':
    unittest.main()
