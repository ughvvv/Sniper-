"""
Tests for historical analysis functionality.
"""
import pytest
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
from pathlib import Path
from src.analysis.price.historical_analysis import HistoricalAnalysis

@pytest.fixture
def sample_data():
    """Create sample data for testing."""
    data = {
        'address': ['token1', 'token1', 'token2', 'token2'],
        'symbol': ['TKN1', 'TKN1', 'TKN2', 'TKN2'],
        'name': ['Token One', 'Token One', 'Token Two', 'Token Two'],
        'current_price': [1.0, 2.0, 0.5, 0.3],
        'price_change_percent': [10.0, 20.0, -5.0, -10.0],
        'volume_24h': [100000, 150000, 50000, 40000],
        'liquidity': [500000, 600000, 200000, 180000],
        'high': [1.1, 2.1, 0.6, 0.4],
        'low': [0.9, 1.9, 0.4, 0.2],
        'avg_volume': [90000, 120000, 45000, 35000],
        'has_twitter': [True, True, False, False],
        'has_telegram': [True, True, True, True],
        'has_website': [True, True, False, False],
        'has_discord': [True, True, False, False],
        'twitter_handle': ['token1', 'token1', None, None],
        'twitter_engagement_rate': [5.0, 6.0, None, None],
        'twitter_followers_growth': [100, 150, None, None],
        'snapshot_date': [
            datetime.now() - timedelta(days=1),
            datetime.now(),
            datetime.now() - timedelta(days=1),
            datetime.now()
        ]
    }
    return pd.DataFrame(data)

@pytest.fixture
def analyzer(tmp_path):
    """Create HistoricalAnalysis instance with temporary directory."""
    return HistoricalAnalysis(tmp_path)

def test_calculate_trend():
    """Test trend calculation."""
    analyzer = HistoricalAnalysis(Path())
    
    # Test positive trend
    values = [1.0, 2.0, 3.0, 4.0]
    trend = analyzer._calculate_trend(values)
    assert trend > 0
    
    # Test negative trend
    values = [4.0, 3.0, 2.0, 1.0]
    trend = analyzer._calculate_trend(values)
    assert trend < 0
    
    # Test flat trend
    values = [1.0, 1.0, 1.0, 1.0]
    trend = analyzer._calculate_trend(values)
    assert trend == 0
    
    # Test empty list
    assert analyzer._calculate_trend([]) == 0

def test_calculate_social_score(sample_data):
    """Test social presence score calculation."""
    analyzer = HistoricalAnalysis(Path())
    
    # Test token with full social presence
    token1_data = sample_data.iloc[0]
    score1 = analyzer._calculate_social_score(token1_data)
    assert score1 > 0
    
    # Test token with partial social presence
    token2_data = sample_data.iloc[2]
    score2 = analyzer._calculate_social_score(token2_data)
    assert score2 < score1
    
    # Verify engagement rate impact
    high_engagement_data = token1_data.copy()
    high_engagement_data['twitter_engagement_rate'] = 20.0
    high_score = analyzer._calculate_social_score(high_engagement_data)
    assert high_score > score1

def test_analyze_performance_trends(analyzer, sample_data):
    """Test performance trends analysis."""
    market_stats = analyzer.analyze_performance_trends(sample_data)
    
    assert isinstance(market_stats, dict)
    assert 'total_tokens_analyzed' in market_stats
    assert 'positive_trend_count' in market_stats
    assert 'negative_trend_count' in market_stats
    assert 'avg_social_presence' in market_stats
    assert 'top_performers' in market_stats
    
    assert market_stats['total_tokens_analyzed'] == 2
    assert len(market_stats['top_performers']) <= 10

def test_identify_launch_patterns(analyzer, sample_data):
    """Test launch pattern identification."""
    patterns = analyzer.identify_launch_patterns(sample_data)
    
    assert isinstance(patterns, list)
    assert len(patterns) == 2  # Two unique tokens in sample data
    
    for pattern in patterns:
        assert 'address' in pattern
        assert 'symbol' in pattern
        assert 'initial_price' in pattern
        assert 'peak_price' in pattern
        assert 'time_to_peak' in pattern
        assert 'had_social_presence' in pattern
        assert 'social_channels_count' in pattern

def test_calculate_growth(sample_data):
    """Test growth rate calculation."""
    analyzer = HistoricalAnalysis(Path())
    
    # Test positive growth
    growth = analyzer._calculate_growth(
        sample_data[sample_data['address'] == 'token1'],
        'twitter_followers_growth'
    )
    assert growth > 0
    
    # Test with missing data
    growth = analyzer._calculate_growth(
        sample_data[sample_data['address'] == 'token2'],
        'twitter_followers_growth'
    )
    assert growth == 0
    
    # Test with single data point
    single_point = sample_data.iloc[[0]]
    growth = analyzer._calculate_growth(single_point, 'twitter_followers_growth')
    assert growth == 0

def test_load_historical_data(analyzer, sample_data, tmp_path):
    """Test historical data loading."""
    # Save sample data to temporary CSV file
    filename = f'top_memecoins_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    sample_data.to_csv(tmp_path / filename, index=False)
    
    # Test loading without date filters
    data = analyzer.load_historical_data()
    assert not data.empty
    assert len(data) == len(sample_data)
    
    # Test loading with date filters
    start_date = datetime.now() - timedelta(days=2)
    end_date = datetime.now() + timedelta(days=1)
    data = analyzer.load_historical_data(start_date, end_date)
    assert not data.empty
    
    # Test loading with future dates
    future_date = datetime.now() + timedelta(days=10)
    data = analyzer.load_historical_data(future_date)
    assert data.empty
