# Solana Meme Coin Analysis

Advanced analysis toolkit for identifying breakout and sell patterns in Solana meme coins using machine learning and technical analysis.

## Features

- **Advanced Pattern Recognition**
  - Breakout pattern detection using multiple technical indicators
  - Machine learning-based anomaly detection
  - Volume profile analysis
  - Support and resistance level identification

- **Machine Learning Integration**
  - LSTM models for pattern prediction
  - Anomaly detection using Isolation Forest
  - Pattern clustering with K-means
  - Confidence scoring system

- **Technical Analysis**
  - Multiple technical indicators (RSI, MACD, Bollinger Bands, etc.)
  - Volume profile analysis
  - Adaptive volatility calculation
  - Dynamic support/resistance levels

- **Data Validation and Preprocessing**
  - Comprehensive data validation
  - Automated data cleaning
  - Outlier detection and handling
  - Feature normalization

- **Visualization**
  - Interactive price charts
  - Volume profile visualization
  - Pattern distribution analysis
  - Technical indicator plots

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/solana_meme_analysis.git
cd solana_meme_analysis
```

2. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Install TA-Lib (required for technical analysis):
- On Linux:
  ```bash
  wget http://prdownloads.sourceforge.net/ta-lib/ta-lib-0.4.0-src.tar.gz
  tar -xzf ta-lib-0.4.0-src.tar.gz
  cd ta-lib/
  ./configure --prefix=/usr
  make
  sudo make install
  pip install TA-Lib
  ```
- On Windows:
  Download and install from: https://www.lfd.uci.edu/~gohlke/pythonlibs/#ta-lib

## Configuration

1. Copy the example environment file:
```bash
cp .env.example .env
```

2. Edit `.env` with your API keys and settings:
```
OPENAI_API_KEY=your_openai_api_key
SOLANA_RPC_URL=your_solana_rpc_url
BIRDEYE_API_KEY=your_birdeye_api_key
```

## Usage

### Basic Pattern Analysis

```python
from src.analysis.price.pattern_recognition import PatternRecognition
from src.collectors.market.price_collector import PriceCollector

# Initialize components
collector = PriceCollector()
pattern_recognition = PatternRecognition()

# Get historical data
df = collector.get_historical_prices("BONK/USD")

# Analyze patterns
patterns, visualizations = pattern_recognition.analyze_breakout_patterns(
    df,
    save_visualizations=True,
    output_dir="output"
)
```

### Using the Example Script

Run the example analysis script:
```bash
python examples/analyze_patterns.py
```

This will:
1. Load historical data for specified tokens
2. Perform pattern analysis
3. Generate visualizations
4. Save results to the output directory

## Advanced Usage

### Custom Pattern Analysis

```python
from src.analysis.ml.pattern_ml import PatternML

# Initialize ML analyzer
ml_analyzer = PatternML()

# Train models
ml_analyzer.train_anomaly_detector(df)
ml_analyzer.train_pattern_classifier(df, labels)

# Get predictions
predictions = ml_analyzer.predict_patterns(df)
anomalies = ml_analyzer.detect_anomalies(df)
```

### Visualization Options

```python
from src.utils.visualization import PatternVisualizer

visualizer = PatternVisualizer()

# Create different types of visualizations
visualizer.plot_price_pattern(df, patterns, "price_patterns.png")
visualizer.create_candlestick_chart(df, patterns, "candlestick.png")
visualizer.plot_pattern_distribution(patterns, "distribution.png")
visualizer.plot_volume_profile_analysis(df, patterns, "volume_profile.png")
```

## Testing

Run the test suite:
```bash
pytest tests/
```

For coverage report:
```bash
pytest --cov=src tests/
```

## Project Structure

```
solana_meme_analysis/
├── src/
│   ├── analysis/
│   │   ├── price/
│   │   │   ├── pattern_recognition.py
│   │   │   ├── historical_analysis.py
│   │   │   └── launch_analyzer.py
│   │   └── ml/
│   │       └── pattern_ml.py
│   ├── collectors/
│   │   ├── market/
│   │   │   └── price_collector.py
│   │   └── social/
│   │       └── social_collector.py
│   ├── utils/
│   │   ├── data_validation.py
│   │   ├── visualization.py
│   │   └── time_utils.py
│   └── config/
│       └── settings.py
├── tests/
│   └── test_pattern_recognition.py
├── examples/
│   └── analyze_patterns.py
├── requirements.txt
└── README.md
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Technical Analysis library: [TA-Lib](https://ta-lib.org/)
- Machine Learning: [scikit-learn](https://scikit-learn.org/)
- Deep Learning: [TensorFlow](https://www.tensorflow.org/)
- Visualization: [mplfinance](https://github.com/matplotlib/mplfinance)
